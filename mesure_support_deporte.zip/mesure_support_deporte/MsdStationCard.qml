/*
 * Mesurer support déporté — carte « POINT A » / « POINT B »
 *   [ PRENDRE POSITION A ]   X / Y / statut / précision
 *   Distance D1 : [______] m
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: card

    property var controller: null
    property string which: "A"          // "A" ou "B"
    property var station: which === "A" ? controller.stationA : controller.stationB
    readonly property string distanceName: which === "A" ? "D1" : "D2"
    readonly property var measure: which === "A" ? controller.d1Measure : controller.d2Measure
    readonly property string distanceText: which === "A" ? controller.d1Text : controller.d2Text
    readonly property bool simulation: controller.config.simulationMode
    readonly property bool simXY: simulation && controller.config.simulationSource === "XY"

    signal distanceFieldFocused(var item)
    signal distanceAccepted()

    function focusDistance() {
        distField.forceActiveFocus();
    }

    Layout.fillWidth: true
    implicitHeight: col.implicitHeight + 20
    radius: 8
    color: station ? "#E8F5E9" : "#F5F5F5"
    border.color: station ? "#1B7F37" : "#9E9E9E"
    border.width: 2

    ColumnLayout {
        id: col
        anchors.fill: parent
        anchors.margins: 10
        spacing: 8

        RowLayout {
            Layout.fillWidth: true
            Label {
                text: "POINT " + card.which
                font.pixelSize: 19
                font.bold: true
                color: "#111111"
            }
            Item { Layout.fillWidth: true }
            Label {
                visible: card.station !== null
                text: "✔ ENREGISTRÉ"
                font.pixelSize: 15
                font.bold: true
                color: "#1B7F37"
            }
        }

        /* Saisie X/Y (mode simulation "XY") */
        RowLayout {
            visible: card.simXY
            Layout.fillWidth: true
            spacing: 6
            TextField {
                id: simX
                Layout.fillWidth: true
                placeholderText: "X " + card.which
                font.pixelSize: 17
                inputMethodHints: Qt.ImhFormattedNumbersOnly | Qt.ImhNoPredictiveText
                text: card.which === "A" ? card.controller.simXA : card.controller.simXB
                onTextEdited: {
                    if (card.which === "A") { card.controller.simXA = text; } else { card.controller.simXB = text; }
                }
            }
            TextField {
                id: simY
                Layout.fillWidth: true
                placeholderText: "Y " + card.which
                font.pixelSize: 17
                inputMethodHints: Qt.ImhFormattedNumbersOnly | Qt.ImhNoPredictiveText
                text: card.which === "A" ? card.controller.simYA : card.controller.simYB
                onTextEdited: {
                    if (card.which === "A") { card.controller.simYA = text; } else { card.controller.simYB = text; }
                }
            }
        }

        MsdBigButton {
            Layout.fillWidth: true
            text: (card.station ? "REPRENDRE POSITION " : "PRENDRE POSITION ") + card.which
            subText: card.simulation ? (card.simXY ? "simulation : X/Y saisis" : "simulation : centre de la carte") : ""
            fillColor: card.station ? "#546E7A" : (card.simulation ? "#6A1B9A" : "#1565C0")
            onClicked: card.controller.requestCapture(card.which)
        }

        /* Coordonnées et qualité de la station */
        GridLayout {
            visible: card.station !== null
            Layout.fillWidth: true
            columns: 2
            columnSpacing: 12
            rowSpacing: 2
            Label { text: "X :"; font.pixelSize: 16; color: "#444444" }
            Label { text: card.station ? card.station.x.toFixed(3) : ""; font.pixelSize: 17; font.bold: true; color: "#111111" }
            Label { text: "Y :"; font.pixelSize: 16; color: "#444444" }
            Label { text: card.station ? card.station.y.toFixed(3) : ""; font.pixelSize: 17; font.bold: true; color: "#111111" }
            Label { text: "GNSS :"; font.pixelSize: 16; color: "#444444" }
            Label {
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                font.pixelSize: 16
                font.bold: true
                color: !card.station ? "#111111" : (card.station.quality === 4 ? "#1B7F37" : (card.station.source === "GNSS" ? "#C0392B" : "#6A1B9A"))
                text: {
                    if (!card.station) {
                        return "";
                    }
                    var t = card.station.qualityLabel;
                    if (card.station.hacc !== null && card.station.hacc !== undefined) {
                        t += " · " + (card.station.hacc * 100).toFixed(1) + " cm";
                    }
                    if (card.station.satellites) {
                        t += " · " + card.station.satellites + " sat";
                    }
                    return t;
                }
            }
            Label { text: "Heure :"; font.pixelSize: 16; color: "#444444" }
            Label {
                text: card.station && card.station.timestamp ? String(card.station.timestamp).substring(11, 19) : ""
                font.pixelSize: 16
                color: "#111111"
            }
        }

        /* Distance D1 / D2 */
        RowLayout {
            Layout.fillWidth: true
            spacing: 8
            Label {
                text: "Distance " + card.distanceName + " :"
                font.pixelSize: 18
                font.bold: true
                color: "#111111"
            }
            TextField {
                id: distField
                Layout.fillWidth: true
                Layout.preferredHeight: 56
                font.pixelSize: 24
                font.bold: true
                horizontalAlignment: TextInput.AlignRight
                placeholderText: "0,00"
                inputMethodHints: Qt.ImhFormattedNumbersOnly | Qt.ImhNoPredictiveText
                validator: RegularExpressionValidator { regularExpression: /^\d{0,4}([.,]\d{0,3})?$/ }
                Component.onCompleted: text = card.distanceText
                onTextEdited: {
                    if (card.which === "A") { card.controller.d1Text = text; } else { card.controller.d2Text = text; }
                }
                onActiveFocusChanged: {
                    if (activeFocus) {
                        card.distanceFieldFocused(distField);
                    }
                }
                onAccepted: card.distanceAccepted()
                background: Rectangle {
                    radius: 6
                    color: "white"
                    border.width: distField.activeFocus ? 3 : 2
                    border.color: card.distanceText === "" ? "#9E9E9E" : (card.measure.ok ? "#1B7F37" : "#C0392B")
                }
            }
            Label {
                text: "m"
                font.pixelSize: 20
                font.bold: true
                color: "#111111"
            }
        }
        Label {
            visible: card.distanceText !== "" && (!card.measure.ok || card.measure.warning !== "")
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            text: card.measure.ok ? "⚠ " + card.measure.warning : "✘ " + card.measure.error
            color: card.measure.ok ? "#D35400" : "#C0392B"
            font.pixelSize: 15
            font.bold: true
        }
    }

    /* Synchronisation si la valeur est changée ailleurs (exemple, recommencer, restauration) */
    Connections {
        target: card.controller
        function onD1TextChanged() {
            if (card.which === "A" && distField.text !== card.controller.d1Text) {
                distField.text = card.controller.d1Text;
            }
        }
        function onD2TextChanged() {
            if (card.which === "B" && distField.text !== card.controller.d2Text) {
                distField.text = card.controller.d2Text;
            }
        }
    }
}
