/*
 * ============================================================================
 *  Mesurer support déporté — Module 4 : panneau principal
 * ============================================================================
 *  Panneau bas d'écran, non modal : la carte reste visible et manipulable
 *  au-dessus pour choisir P1 / P2.
 *   - mode complet : GNSS, point A, point B, baseline, calcul, résultat ;
 *   - mode réduit  : automatiquement après le calcul (qualité + choix P1/P2
 *                    + validation), pour libérer la carte.
 *  Quand le clavier est ouvert, le panneau passe en haut de l'écran.
 *  Contraste élevé, polices >= 15 px, boutons de 56 px (soleil, gants).
 * ============================================================================
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import "js/quality.js" as Quality

Rectangle {
    id: panel

    property var controller: null
    property var gnss: null
    property bool compact: false
    readonly property bool keyboardUp: Qt.inputMethod.visible
    readonly property var cfg: controller.config
    readonly property var res: controller.result
    readonly property var ev: controller.evaluation
    readonly property real topMargin: controller.mainWindow && controller.mainWindow.sceneTopMargin ? controller.mainWindow.sceneTopMargin : 0
    readonly property real bottomMargin: controller.mainWindow && controller.mainWindow.sceneBottomMargin ? controller.mainWindow.sceneBottomMargin : 0

    visible: controller.panelOpen && parent !== null
    width: parent ? Math.min(parent.width, 620) : 400
    x: parent ? (parent.width - width) / 2 : 0
    y: parent ? (keyboardUp ? topMargin : parent.height - height - bottomMargin) : 0
    height: {
        if (!parent) {
            return 300;
        }
        var maxH = keyboardUp ? parent.height * 0.48 : parent.height * 0.66;
        var wanted = header.height + banner.height + (compact ? compactCol.implicitHeight : fullCol.implicitHeight) + 24;
        return Math.min(maxH, wanted);
    }
    color: "white"
    border.color: "#212121"
    border.width: 2
    radius: 10

    /* Bloque les gestes vers la carte sous le panneau */
    MouseArea {
        anchors.fill: parent
        onWheel: function (wheel) { wheel.accepted = true; }
    }

    function flash(message, type) {
        if (compact && type === "info") {
            return;   // en mode réduit, on préserve la place pour la carte
        }
        banner.text = message;
        banner.kind = type;
        bannerTimer.restart();
    }

    /* Bande de la carte (coordonnées de `item`) non masquée par le panneau */
    function visibleMapBand(item) {
        var top = topMargin + 64;
        var bottom = item.height;
        if (visible && !keyboardUp) {
            bottom = panel.mapToItem(item, 0, 0).y - 8;
        }
        return { top: top, bottom: bottom };
    }

    function resetView() {
        compact = false;
        flick.contentY = 0;
    }

    function ensureVisible(item, offset) {
        if (!item) {
            return;
        }
        var p = item.mapToItem(fullCol, 0, 0);
        var target = Math.max(0, p.y - (offset === undefined ? 70 : offset));
        flick.contentY = Math.min(target, Math.max(0, flick.contentHeight - flick.height));
    }

    /* laisse la mise en page se stabiliser avant de faire défiler vers le verdict */
    Timer {
        id: scrollToResultTimer
        interval: 120
        onTriggered: panel.ensureVisible(fullQuality, 4)
    }

    Connections {
        target: panel.controller
        function onResultChanged() {
            if (panel.controller.result && panel.controller.result.ok) {
                if (banner.kind === "info") {
                    banner.text = "";
                }
                panel.compact = true;
            } else if (panel.controller.result) {
                panel.compact = false;
                scrollToResultTimer.restart();
            }
        }
    }

    /* ---------------- En-tête ---------------- */
    Rectangle {
        id: header
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 2
        height: 52
        radius: 8
        color: "#212121"

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 4
            spacing: 4
            Label {
                Layout.fillWidth: true
                text: "SUPPORT DÉPORTÉ"
                color: "white"
                font.pixelSize: 17
                font.bold: true
                elide: Text.ElideRight
            }
            MsdIconButton {
                text: panel.compact ? "▲" : "▼"
                onClicked: panel.compact = !panel.compact
            }
            MsdIconButton {
                text: "⚙"
                onClicked: panel.controller.openSettings()
            }
            MsdIconButton {
                text: "✕"
                onClicked: panel.controller.panelOpen = false
            }
        }
    }

    /* ---------------- Bandeau de message ---------------- */
    Rectangle {
        id: banner
        property string text: ""
        property string kind: "info"
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 4
        height: text === "" ? 0 : bannerLabel.implicitHeight + 12
        visible: text !== ""
        radius: 6
        color: kind === "error" ? "#C0392B" : (kind === "warning" ? "#D35400" : "#37474F")
        Label {
            id: bannerLabel
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 6
            text: banner.text
            color: "white"
            font.pixelSize: 15
            font.bold: true
            wrapMode: Text.WordWrap
        }
        MouseArea {
            anchors.fill: parent
            onClicked: banner.text = ""
        }
        Timer {
            id: bannerTimer
            interval: banner.kind === "error" ? 7000 : 4500
            onTriggered: banner.text = ""
        }
    }

    Flickable {
        id: flick
        anchors.top: banner.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 10
        clip: true
        contentWidth: width
        contentHeight: panel.compact ? compactCol.implicitHeight : fullCol.implicitHeight
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded; width: 10 }

        /* ================= MODE RÉDUIT ================= */
        ColumnLayout {
            id: compactCol
            visible: panel.compact
            width: flick.width - 12
            spacing: 8

            MsdQualityBadge {
                Layout.fillWidth: true
                evaluation: panel.ev
                compactStyle: true
                onClicked: panel.compact = false
            }
            MsdCandidateButtons { Layout.fillWidth: true; controller: panel.controller; showHelp: false }
            MsdResultActions { Layout.fillWidth: true; controller: panel.controller }
        }

        /* ================= MODE COMPLET ================= */
        ColumnLayout {
            id: fullCol
            visible: !panel.compact
            width: flick.width - 12
            spacing: 10

            MsdGnssBadge { gnss: panel.gnss; simulation: panel.cfg.simulationMode; Layout.fillWidth: true }

            Label {
                visible: panel.controller.sessionRestored
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                text: "Mesure en cours restaurée (fenêtre fermée ou QField redémarré)."
                font.pixelSize: 14
                font.italic: true
                color: "#37474F"
            }

            MsdStationCard {
                id: cardA
                controller: panel.controller
                which: "A"
                onDistanceFieldFocused: function (item) { Qt.callLater(panel.ensureVisible, cardA); }
                onDistanceAccepted: cardB.focusDistance()
            }

            MsdStationCard {
                id: cardB
                controller: panel.controller
                which: "B"
                onDistanceFieldFocused: function (item) { Qt.callLater(panel.ensureVisible, cardB); }
                onDistanceAccepted: {
                    Qt.inputMethod.hide();
                    if (panel.controller.canCompute) {
                        panel.controller.compute();
                    }
                }
            }

            /* Baseline AB en direct */
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: baseRow.implicitHeight + 16
                radius: 8
                readonly property string cls: Quality.baselineClass(panel.controller.baselineAB, panel.cfg)
                color: cls === "BON" ? "#E8F5E9" : (cls === "A_CONTROLER" ? "#FFF3E0" : (cls === "REPRENDRE" ? "#FFEBEE" : "#F5F5F5"))
                border.color: cls === "BON" ? "#1B7F37" : (cls === "A_CONTROLER" ? "#D35400" : (cls === "REPRENDRE" ? "#C0392B" : "#9E9E9E"))
                border.width: 2
                ColumnLayout {
                    id: baseRow
                    anchors.fill: parent
                    anchors.margins: 8
                    spacing: 2
                    Label {
                        text: "Baseline AB : " + (isNaN(panel.controller.baselineAB) ? "—" : panel.controller.baselineAB.toFixed(2) + " m")
                        font.pixelSize: 19
                        font.bold: true
                        color: "#111111"
                    }
                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        font.pixelSize: 14
                        color: "#37474F"
                        text: {
                            var b = panel.controller.baselineAB;
                            if (isNaN(b)) {
                                return "Recommandé : " + panel.cfg.baselineOptimalMin + " à " + panel.cfg.baselineOptimalMax + " m entre A et B.";
                            }
                            if (b < panel.cfg.baselineMinRecommended) {
                                return "Géométrie faible : éloignez-vous davantage avant la deuxième mesure.";
                            }
                            if (b < panel.cfg.baselineOptimalMin) {
                                return "Acceptable. Optimal : " + panel.cfg.baselineOptimalMin + " à " + panel.cfg.baselineOptimalMax + " m.";
                            }
                            return "Bonne baseline.";
                        }
                    }
                    Label {
                        visible: panel.controller.calcCrsAuthid !== ""
                        text: "CRS de calcul : " + panel.controller.calcCrsAuthid +
                              (panel.controller.calcCrsOrigin === "CARTE" ? " (carte)" : (panel.controller.calcCrsOrigin === "UTM" ? " (UTM auto)" : " (paramètres)"))
                        font.pixelSize: 13
                        color: "#546E7A"
                    }
                }
            }

            MsdBigButton {
                Layout.fillWidth: true
                text: "CALCULER"
                fontSize: 21
                fillColor: "#1B7F37"
                enabled: panel.controller.canCompute
                onClicked: {
                    Qt.inputMethod.hide();
                    panel.controller.compute();
                }
            }

            /* ------------ Résultat ------------ */
            MsdQualityBadge { id: fullQuality; Layout.fillWidth: true; evaluation: panel.ev; visible: panel.ev !== null; onClicked: {} }

            Repeater {
                model: panel.ev ? panel.ev.messages : []
                delegate: Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    font.pixelSize: 15
                    font.bold: modelData.level !== "INFO"
                    color: modelData.level === "ERREUR" ? "#C0392B" : (modelData.level === "ALERTE" ? "#D35400" : "#37474F")
                    text: (modelData.level === "ERREUR" ? "✘ " : (modelData.level === "ALERTE" ? "⚠ " : "ℹ ")) + modelData.text
                }
            }

            GridLayout {
                visible: panel.res !== null && panel.res.ok
                Layout.fillWidth: true
                columns: 2
                columnSpacing: 12
                rowSpacing: 2
                Label { text: "Angle d'intersection :"; font.pixelSize: 14; color: "#444444" }
                Label { text: panel.res && isFinite(panel.res.intersectionAngleDeg) ? panel.res.intersectionAngleDeg.toFixed(0) + "°" : "—"; font.pixelSize: 14; font.bold: true }
                Label { text: "Écart des cercles :"; font.pixelSize: 14; color: "#444444" }
                Label { text: panel.res && isFinite(panel.res.gap) ? (panel.res.gap * 100).toFixed(1) + " cm" : "—"; font.pixelSize: 14; font.bold: true }
                Label { text: "Incertitude indicative :"; font.pixelSize: 14; color: "#444444" }
                Label {
                    text: panel.ev && isFinite(panel.ev.metrics.sigmaIndicative) ? "± " + (panel.ev.metrics.sigmaIndicative * 100).toFixed(0) + " cm (modèle simplifié)" : "—"
                    font.pixelSize: 14
                    font.bold: true
                }
            }

            MsdCandidateButtons { Layout.fillWidth: true; controller: panel.controller }
            MsdResultActions { Layout.fillWidth: true; controller: panel.controller }

            /* ------------ Bas de panneau ------------ */
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                MsdBigButton {
                    Layout.fillWidth: true
                    text: "RECOMMENCER"
                    fillColor: "#ECEFF1"
                    textColor: "#C0392B"
                    onClicked: panel.controller.requestRestart()
                }
                MsdBigButton {
                    visible: panel.cfg.simulationMode
                    Layout.fillWidth: true
                    text: "EXEMPLE"
                    subText: "données de test"
                    fillColor: "#6A1B9A"
                    onClicked: panel.controller.loadExample()
                }
            }
            Label {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: "v" + panel.controller.pluginVersion + " · Trilatération 2 points · distances manuelles"
                font.pixelSize: 12
                color: "#78909C"
            }
            Item { implicitHeight: 8 }
        }
    }
}
