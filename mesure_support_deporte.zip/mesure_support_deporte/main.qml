/*
 * ============================================================================
 *  Mesurer support déporté — plugin QField
 *  Mode : Trilatération 2 points (GNSS RTK + 2 distances saisies)
 * ============================================================================
 *
 *  Point d'entrée du plugin et CONTRÔLEUR : il détient l'état de la mesure
 *  et orchestre les modules :
 *    Module 1  GNSS ................ MsdGnssService.qml
 *    Module 2  Moteur .............. js/trilateration.js (+ js/geodesy.js)
 *    Module 3  Contrôle qualité .... js/quality.js
 *    Module 4  Interface ........... MsdPanel.qml, MsdMapOverlay.qml, MsdSettingsDialog.qml
 *    Module 5  Création d'entité ... PHASE 4 (non incluse) — voir createFeatureHook()
 *    Module 6  Configuration ....... js/config.js (+ settings QField)
 *    Distances ..................... js/distance_providers.js (ManualDistanceProvider)
 *    Journal / session ............. js/journal.js
 *
 *  Version prototype : Phases 1 à 3 (prise A/B, D1/D2, calcul, P1/P2 sur carte,
 *  contrôle qualité, journal CSV de validation terrain, mode simulation).
 * ============================================================================
 */
import QtQuick
import QtQuick.Controls

import org.qfield
import org.qgis
import Theme

import "js/trilateration.js" as Trilat
import "js/quality.js" as Quality
import "js/config.js" as Config
import "js/distance_providers.js" as Distance
import "js/journal.js" as Journal
import "js/geodesy.js" as Geodesy

Item {
    id: plugin

    readonly property string pluginVersion: "0.3.0"

    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var positionSource: iface.findItemByObjectName('positionSource')

    /* ---------------- Module 6 : configuration ---------------- */
    property var config: Config.defaults()

    /* ---------------- État de la mesure en cours ---------------- */
    property var stationA: null          // {x, y, z (CRS calcul), mapX, mapY, hacc, quality, qualityLabel, source, timestamp, ...}
    property var stationB: null
    property string d1Text: ""
    property string d2Text: ""
    property string simXA: ""
    property string simYA: ""
    property string simXB: ""
    property string simYB: ""
    property string calcCrsAuthid: ""    // CRS de calcul de la session (figé à la prise de A)
    property string calcCrsOrigin: ""
    property var result: null            // résultat de Trilat.intersectCircles
    property var evaluation: null        // résultat de Quality.evaluate
    property int selectedIndex: -1
    property real scaleFactor: NaN
    property var validatedPoints: []     // supports journalisés pendant la session (affichage carte)
    property int journalCounter: 0
    property bool panelOpen: false
    property bool sessionRestored: false

    readonly property var distanceProvider: Distance.getProvider(Distance.PROVIDER_MANUAL)
    readonly property var d1Measure: distanceProvider.parse(d1Text, config)
    readonly property var d2Measure: distanceProvider.parse(d2Text, config)
    readonly property real baselineAB: (stationA && stationB) ? Trilat.distance(stationA, stationB) : NaN
    readonly property bool canCompute: stationA !== null && stationB !== null && d1Measure.ok && d2Measure.ok
    readonly property var selectedCandidate: (result && selectedIndex >= 0 && selectedIndex < result.candidates.length)
                                             ? result.candidates[selectedIndex] : null
    readonly property var statusInfo: evaluation ? Quality.STATUS_INFO[evaluation.status] : null

    /* Données d'affichage cartographique (recalculées à chaque changement d'état) */
    property var overlayData: buildOverlay(stationA, stationB, result, selectedIndex, d1Measure, d2Measure,
                                           validatedPoints, calcCrsAuthid, scaleFactor,
                                           mapCanvas ? mapCanvas.mapSettings.destinationCrs : null)

    /* ---------------- Modules ---------------- */
    MsdGnssService {
        id: gnss
        positionSource: plugin.positionSource
    }

    MsdCrsService {
        id: crsService
        mapSettings: plugin.mapCanvas ? plugin.mapCanvas.mapSettings : null
        config: plugin.config
    }

    MsdMapOverlay {
        id: overlay
        parent: plugin.mapCanvas
        anchors.fill: parent
        z: 1000
        controller: plugin
        visible: plugin.panelOpen && plugin.mapCanvas !== null
    }

    MsdPanel {
        id: panel
        parent: plugin.mainWindow ? plugin.mainWindow.contentItem : null
        controller: plugin
        gnss: gnss
        z: 9000
    }

    MsdSettingsDialog {
        id: settingsDialog
        parent: plugin.mainWindow ? plugin.mainWindow.contentItem : null
        controller: plugin
        z: 10000
    }

    MsdConfirmDialog {
        id: confirmDialog
        parent: plugin.mainWindow ? plugin.mainWindow.contentItem : null
        z: 10001
    }

    QfToolButton {
        id: toolButton
        bgcolor: plugin.panelOpen ? "#1B7F37" : Theme.darkGray
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: "transparent"
        round: true
        onClicked: plugin.panelOpen = !plugin.panelOpen
        onPressAndHold: settingsDialog.openWith(plugin.config)
    }

    Component.onCompleted: {
        loadConfig();
        restoreSession();
        iface.addItemToPluginsToolbar(toolButton);
    }

    /* ======================================================================
     *  Utilitaires
     * ====================================================================== */
    function toast(message, type) {
        if (mainWindow && mainWindow.displayToast) {
            mainWindow.displayToast(message, type || "info");
        }
        panel.flash(message, type || "info");
    }

    function log(message) {
        try {
            iface.logMessage("[Support déporté] " + message);
        } catch (e) {
            console.log("[Support déporté] " + message);
        }
    }

    function projectPath() {
        return (typeof qgisProject !== "undefined" && qgisProject) ? String(qgisProject.fileName) : "";
    }

    function calcCrs() {
        return crsService.fromAuthid(calcCrsAuthid);
    }

    function mapCrs() {
        return mapCanvas ? mapCanvas.mapSettings.destinationCrs : null;
    }

    /* ======================================================================
     *  Module 6 : configuration
     * ====================================================================== */
    function loadConfig() {
        var stored = "";
        try {
            stored = settings.value(Config.SETTINGS_KEY_CONFIG, "");
        } catch (e) {
            stored = "";
        }
        var r = Config.fromJson(stored);
        config = r.config;
        for (var i = 0; i < r.warnings.length; i++) {
            log("Configuration : " + r.warnings[i]);
        }
    }

    function saveConfig(draft) {
        var r = Config.merge(draft);
        var modeChanged = (r.config.calcCrsMode !== config.calcCrsMode) || (r.config.fallbackCrs !== config.fallbackCrs);
        config = r.config;
        try {
            settings.setValue(Config.SETTINGS_KEY_CONFIG, Config.toJson(config));
        } catch (e) {
            log("Échec d'enregistrement de la configuration : " + e);
        }
        if (r.warnings.length > 0) {
            toast("Paramètres corrigés : " + r.warnings.join(" "), "warning");
        } else {
            toast("Paramètres enregistrés.", "info");
        }
        if (modeChanged && (stationA || stationB)) {
            toast("CRS de calcul modifié : il s'appliquera à la prochaine mesure (RECOMMENCER).", "warning");
        }
        invalidateResult();
    }

    function resetConfig() {
        saveConfig(Config.defaults());
    }

    /* ======================================================================
     *  Session : conservation des mesures (changement de fenêtre, redémarrage)
     * ====================================================================== */
    function saveSession() {
        try {
            settings.setValue(Config.SETTINGS_KEY_SESSION, Journal.serializeSession({
                stationA: stationA, stationB: stationB, d1Text: d1Text, d2Text: d2Text,
                crsAuthid: calcCrsAuthid, projectPath: projectPath(),
                simXA: simXA, simYA: simYA, simXB: simXB, simYB: simYB
            }));
        } catch (e) {
            log("Session non enregistrée : " + e);
        }
    }

    function restoreSession() {
        var text = "";
        try {
            text = settings.value(Config.SETTINGS_KEY_SESSION, "");
        } catch (e) {
            text = "";
        }
        var s = Journal.restoreSession(text);
        simXA = s.simXA; simYA = s.simYA; simXB = s.simXB; simYB = s.simYB;
        if (s.projectPath !== "" && s.projectPath !== projectPath()) {
            return;   // mesure d'un autre projet : ignorée
        }
        if (!s.stationA && !s.stationB && s.d1Text === "" && s.d2Text === "") {
            return;
        }
        calcCrsAuthid = s.crsAuthid;
        stationA = refreshMapCoordinates(s.stationA);
        stationB = refreshMapCoordinates(s.stationB);
        d1Text = s.d1Text;
        d2Text = s.d2Text;
        sessionRestored = true;
        log("Mesure en cours restaurée.");
    }

    function refreshMapCoordinates(st) {
        if (!st) {
            return null;
        }
        var c = calcCrs();
        var m = mapCrs();
        var p = (c && m) ? crsService.transform(st.x, st.y, c, m) : null;
        var copy = JSON.parse(JSON.stringify(st));
        if (p) {
            copy.mapX = p.x;
            copy.mapY = p.y;
        }
        return copy;
    }

    function scheduleSave() {
        Qt.callLater(saveSession);
    }

    onD1TextChanged: { invalidateResult(); scheduleSave(); }
    onD2TextChanged: { invalidateResult(); scheduleSave(); }

    /* ======================================================================
     *  Module 1 : prise de position A / B
     * ====================================================================== */
    function hasStation(which) {
        return which === "A" ? stationA !== null : stationB !== null;
    }

    /* Appelé par l'interface : demande confirmation avant écrasement. */
    function requestCapture(which) {
        if (hasStation(which)) {
            confirmDialog.ask("Reprendre la position " + which + " ?",
                              "La position " + which + " déjà enregistrée sera remplacée. Le calcul sera à refaire.",
                              "REMPLACER", function () { capture(which); });
            return;
        }
        capture(which);
    }

    function capture(which) {
        /* 1. CRS de calcul : figé à la première position de la mesure */
        var hint = null;
        var snap = null;
        if (!config.simulationMode) {
            snap = gnss.snapshot();
            if (!snap.ok) {
                toast(snap.error, "error");
                return false;
            }
            hint = { lon: snap.meta.lon, lat: snap.meta.lat };
        }
        if (calcCrsAuthid === "" || (!stationA && !stationB)) {
            var rc = crsService.resolveCalcCrs(hint);
            if (!rc.ok) {
                toast(rc.error, "error");
                return false;
            }
            calcCrsAuthid = rc.authid;
            calcCrsOrigin = rc.origin;
        }
        var cCrs = calcCrs();
        var mCrs = mapCrs();
        if (!cCrs || !mCrs) {
            toast("CRS de calcul ou de carte invalide.", "error");
            return false;
        }

        /* 2. Coordonnées selon la source */
        var st = null;
        if (config.simulationMode) {
            st = simulatedStation(which, cCrs, mCrs);
            if (!st) {
                return false;
            }
        } else {
            var srcCrs = snap.crs && crsService.isValidCrs(snap.crs) ? snap.crs : mCrs;
            var pc = crsService.transform(snap.point.x, snap.point.y, srcCrs, cCrs);
            var pm = crsService.transform(snap.point.x, snap.point.y, srcCrs, mCrs);
            if (!pc || !pm) {
                toast("Transformation de coordonnées impossible vers " + calcCrsAuthid + ".", "error");
                return false;
            }
            st = {
                x: pc.x, y: pc.y, z: snap.point.z,
                mapX: pm.x, mapY: pm.y,
                hacc: snap.meta.hacc, quality: snap.meta.quality, qualityLabel: snap.meta.qualityLabel,
                qualityText: snap.meta.qualityText, fixText: snap.meta.fixText,
                satellites: snap.meta.satellites, lon: snap.meta.lon, lat: snap.meta.lat,
                source: "GNSS", timestamp: snap.meta.timestamp, crs: calcCrsAuthid
            };
            if (snap.warning) {
                toast(snap.warning, "warning");
            }
        }

        if (which === "A") {
            stationA = st;
        } else {
            stationB = st;
        }
        invalidateResult();
        scheduleSave();

        var msg = "Position " + which + " enregistrée";
        if (st.source === "GNSS") {
            msg += " — " + st.qualityLabel + (st.hacc !== null && st.hacc !== undefined ? " · " + (st.hacc * 100).toFixed(1) + " cm" : "");
        } else {
            msg += " (simulation)";
        }
        toast(msg, "info");
        if (stationA && stationB && baselineAB < config.baselineMinRecommended) {
            toast("Géométrie faible : éloignez-vous davantage avant la deuxième mesure (AB = " + baselineAB.toFixed(2) + " m).", "warning");
        }
        return true;
    }

    function _parseCoord(text) {
        var s = String(text || "").trim().replace(",", ".");
        if (s === "" || !/^-?\d+(\.\d+)?$/.test(s)) {
            return NaN;
        }
        return parseFloat(s);
    }

    function simulatedStation(which, cCrs, mCrs) {
        var ts = Journal.isoLocal(new Date());
        var pc, pm;
        if (config.simulationSource === "XY") {
            var x = _parseCoord(which === "A" ? simXA : simXB);
            var y = _parseCoord(which === "A" ? simYA : simYB);
            if (isNaN(x) || isNaN(y)) {
                toast("Simulation : saisissez X et Y de " + which + " (" + calcCrsAuthid + ").", "error");
                return null;
            }
            pc = { x: x, y: y };
            pm = crsService.transform(x, y, cCrs, mCrs);
        } else {
            var c = mapCanvas.mapSettings.center;
            pm = { x: c.x, y: c.y };
            pc = crsService.transform(c.x, c.y, mCrs, cCrs);
            if (which === "A") {
                simXA = pc ? pc.x.toFixed(3) : "";
                simYA = pc ? pc.y.toFixed(3) : "";
            } else {
                simXB = pc ? pc.x.toFixed(3) : "";
                simYB = pc ? pc.y.toFixed(3) : "";
            }
        }
        if (!pc || !pm) {
            toast("Simulation : transformation de coordonnées impossible.", "error");
            return null;
        }
        return {
            x: pc.x, y: pc.y, z: NaN, mapX: pm.x, mapY: pm.y,
            hacc: null, quality: null, qualityLabel: "SIMULATION",
            source: config.simulationSource === "XY" ? "SIMULATION_XY" : "SIMULATION_CENTRE",
            timestamp: ts, crs: calcCrsAuthid
        };
    }

    /* Exemple de démonstration (mode simulation) : géométrie du test n°10,
       placée au centre de la carte. */
    function loadExample() {
        var mCrs = mapCrs();
        var rc = crsService.resolveCalcCrs(null);
        if (!rc.ok || !mCrs) {
            toast("Exemple impossible : " + rc.error, "error");
            return;
        }
        calcCrsAuthid = rc.authid;
        calcCrsOrigin = rc.origin;
        var cCrs = calcCrs();
        var c = mapCanvas.mapSettings.center;
        var pc = crsService.transform(c.x, c.y, mCrs, cCrs);
        if (!pc) {
            toast("Exemple impossible : transformation du centre de carte.", "error");
            return;
        }
        var az = 56.7 * Math.PI / 180;
        var bx = pc.x + 14.60 * Math.sin(az);
        var by = pc.y + 14.60 * Math.cos(az);
        var pmA = crsService.transform(pc.x, pc.y, cCrs, mCrs);
        var pmB = crsService.transform(bx, by, cCrs, mCrs);
        var ts = Journal.isoLocal(new Date());
        stationA = { x: pc.x, y: pc.y, z: NaN, mapX: pmA.x, mapY: pmA.y, hacc: null, quality: null,
                     qualityLabel: "SIMULATION", source: "SIMULATION_EXEMPLE", timestamp: ts, crs: calcCrsAuthid };
        stationB = { x: bx, y: by, z: NaN, mapX: pmB.x, mapY: pmB.y, hacc: null, quality: null,
                     qualityLabel: "SIMULATION", source: "SIMULATION_EXEMPLE", timestamp: ts, crs: calcCrsAuthid };
        simXA = pc.x.toFixed(3); simYA = pc.y.toFixed(3);
        simXB = bx.toFixed(3); simYB = by.toFixed(3);
        d1Text = "11,26";
        d2Text = "8,45";
        invalidateResult();
        scheduleSave();
        toast("Exemple chargé : AB = 14,60 m, D1 = 11,26 m, D2 = 8,45 m. Appuyez sur CALCULER.", "info");
    }

    /* ======================================================================
     *  Modules 2 + 3 : calcul et contrôle qualité
     * ====================================================================== */
    function invalidateResult() {
        result = null;
        evaluation = null;
        selectedIndex = -1;
    }

    function compute() {
        if (!stationA || !stationB) {
            toast("Prenez d'abord les positions A et B.", "error");
            return;
        }
        if (!d1Measure.ok) {
            toast("D1 : " + d1Measure.error, "error");
            return;
        }
        if (!d2Measure.ok) {
            toast("D2 : " + d2Measure.error, "error");
            return;
        }
        var cCrs = calcCrs();

        /* Facteur d'échelle local : D_grille = k x D_mesurée */
        var k = NaN;
        if (config.applyScaleFactor && cCrs) {
            k = crsService.scaleFactorAt((stationA.x + stationB.x) / 2, (stationA.y + stationB.y) / 2, cCrs);
        }
        scaleFactor = k;
        var r1 = Geodesy.groundToGrid(d1Measure.value, k);
        var r2 = Geodesy.groundToGrid(d2Measure.value, k);

        var opts = Quality.engineOptions(stationA, stationB, config);
        var res = Trilat.intersectCircles(stationA, r1, stationB, r2, opts);
        var ev = Quality.evaluate({
            result: res, stationA: stationA, stationB: stationB,
            d1: d1Measure.value, d2: d2Measure.value, config: config
        });
        if (config.applyScaleFactor) {
            if (isNaN(k)) {
                ev.messages.push({ level: Quality.LEVEL.INFO, code: "SCALE_NA", text: "Facteur d'échelle non calculable : distances utilisées telles que mesurées." });
            } else {
                ev.messages.push({ level: Quality.LEVEL.INFO, code: "SCALE",
                                   text: "Facteur d'échelle " + calcCrsAuthid + " : k = " + k.toFixed(6) +
                                         " (" + ((k - 1) * 1e6).toFixed(0) + " ppm, " + ((k - 1) * 10000).toFixed(1) + " mm / 10 m)." });
            }
        }
        ev.metrics.scaleFactor = k;

        /* Présélection : solution unique, ou côté configuré */
        var sel = -1;
        if (res.ok && res.candidates.length === 1) {
            sel = 0;
        } else if (res.ok && res.candidates.length === 2) {
            if (config.defaultSide === "GAUCHE") {
                sel = 0;
            } else if (config.defaultSide === "DROITE") {
                sel = 1;
            }
        }
        result = res;
        evaluation = ev;
        selectedIndex = sel;

        log("Calcul " + res.caseId + " / " + ev.status + " / AB=" + (isNaN(res.baseline) ? "?" : res.baseline.toFixed(3)) +
            " D1=" + d1Measure.value + " D2=" + d2Measure.value + " k=" + k);

        if (res.ok && config.autoZoom) {
            zoomToMeasure();
        }
        if (res.ok && res.candidates.length === 2 && sel < 0) {
            toast("Touchez le bon support sur la carte : P1 (gauche) ou P2 (droite).", "info");
        }
    }

    function selectCandidate(index) {
        if (!result || !result.ok || index < 0 || index >= result.candidates.length) {
            return;
        }
        selectedIndex = index;
    }

    /* Cadre la carte sur A, B et les solutions, dans la bande de carte restée
       visible au-dessus du panneau (sinon P2 peut se retrouver sous le panneau). */
    function zoomToMeasure() {
        if (!mapCanvas) {
            return;
        }
        var pts = [];
        var i;
        if (stationA) { pts.push({ x: stationA.mapX, y: stationA.mapY }); }
        if (stationB) { pts.push({ x: stationB.mapX, y: stationB.mapY }); }
        var od = overlayData;
        for (i = 0; i < od.candidates.length; i++) {
            pts.push({ x: od.candidates[i].mapX, y: od.candidates[i].mapY });
        }
        if (pts.length < 2) {
            return;
        }
        var minX = pts[0].x, maxX = pts[0].x, minY = pts[0].y, maxY = pts[0].y;
        for (i = 1; i < pts.length; i++) {
            minX = Math.min(minX, pts[i].x); maxX = Math.max(maxX, pts[i].x);
            minY = Math.min(minY, pts[i].y); maxY = Math.max(maxY, pts[i].y);
        }
        var W = mapCanvas.width;
        var H = mapCanvas.height;
        if (!(W > 0) || !(H > 0)) {
            return;
        }
        var band = panel.visibleMapBand(mapCanvas);
        var availH = Math.max(140, band.bottom - band.top);
        var minSpan = crsService.isMetricProjected(mapCrs()) ? 20 : 0.0002;
        var spanW = Math.max((maxX - minX) * 1.6, minSpan);
        var spanH = Math.max((maxY - minY) * 1.6, minSpan);
        var mupp = Math.max(spanW / Math.max(100, W - 40), spanH / availH);
        var cx = (minX + maxX) / 2;
        var screenCenterY = band.top + availH / 2;
        var cy = (minY + maxY) / 2 - (H / 2 - screenCenterY) * mupp;
        var rect = GeometryUtils.createRectangleFromPoints(GeometryUtils.point(cx - W / 2 * mupp, cy - H / 2 * mupp),
                                                           GeometryUtils.point(cx + W / 2 * mupp, cy + H / 2 * mupp));
        mapCanvas.mapSettings.setExtent(rect, true);
    }

    /* ======================================================================
     *  Affichage cartographique (Module 4)
     * ====================================================================== */
    function buildOverlay(A, B, res, sel, m1, m2, validated, authid, k, mapCrsDep) {
        var out = { stations: [], candidates: [], validated: [], ok: false };
        var cCrs = crsService.fromAuthid(authid);
        var mCrs = mapCrs();
        if (!cCrs || !mCrs) {
            return out;
        }
        var kk = isNaN(k) ? 1.0 : k;
        function edge(st, measure) {
            if (!st || !measure || !measure.ok) {
                return null;
            }
            return crsService.transform(st.x + measure.value * kk, st.y, cCrs, mCrs);
        }
        if (A) {
            out.stations.push({ label: "A", mapX: A.mapX, mapY: A.mapY, edge: edge(A, m1) });
        }
        if (B) {
            out.stations.push({ label: "B", mapX: B.mapX, mapY: B.mapY, edge: edge(B, m2) });
        }
        if (res && res.ok) {
            for (var i = 0; i < res.candidates.length; i++) {
                var c = res.candidates[i];
                var pm = crsService.transform(c.x, c.y, cCrs, mCrs);
                if (!pm) {
                    continue;
                }
                var sideTxt = c.side === "GAUCHE" ? "gauche" : (c.side === "DROITE" ? "droite" : "axe");
                out.candidates.push({ index: i, id: c.id, label: c.id + " · " + sideTxt, side: c.side,
                                      mapX: pm.x, mapY: pm.y, selected: i === sel });
            }
        }
        for (var j = 0; j < validated.length; j++) {
            out.validated.push(validated[j]);
        }
        out.ok = true;
        return out;
    }

    /* ======================================================================
     *  Validation + journal CSV (traçabilité, protocole de validation terrain)
     * ====================================================================== */
    function requestValidate() {
        if (!selectedCandidate) {
            toast("Sélectionnez d'abord le support (P1 ou P2).", "error");
            return;
        }
        if (evaluation.status === Quality.STATUS.REPRENDRE) {
            toast("Qualité insuffisante : reprenez la mesure.", "error");
            return;
        }
        if (evaluation.status === Quality.STATUS.A_CONTROLER) {
            confirmDialog.ask("Mesure à contrôler", "La qualité est « À CONTRÔLER ». Enregistrer quand même ce support ?",
                              "ENREGISTRER", function () { validate(); });
            return;
        }
        validate();
    }

    function validate() {
        var now = new Date();
        journalCounter += 1;
        var sel = selectedCandidate;
        var record = {
            id: Journal.makeId(now, journalCounter),
            date: Journal.isoLocal(now),
            operator: config.operator,
            crsAuthid: calcCrsAuthid,
            stationA: stationA, stationB: stationB,
            d1: d1Measure.value, d2: d2Measure.value,
            result: result, evaluation: evaluation,
            selected: sel
        };
        var row = Journal.buildRow(record);
        var written = false;
        if (config.journalEnabled) {
            written = appendJournal(row);
        }

        /* Point affiché sur la carte pendant la session */
        var od = overlayData;
        var mp = null;
        for (var i = 0; i < od.candidates.length; i++) {
            if (od.candidates[i].index === selectedIndex) {
                mp = od.candidates[i];
            }
        }
        if (mp) {
            var list = validatedPoints.slice(0);
            list.push({ mapX: mp.mapX, mapY: mp.mapY, label: String(journalCounter), status: evaluation.status });
            validatedPoints = list;
        }

        createFeatureHook(record);

        log("Support validé " + record.id + " X=" + sel.x.toFixed(3) + " Y=" + sel.y.toFixed(3) + " (" + calcCrsAuthid + ")");
        toast("Support " + record.id + " : X " + sel.x.toFixed(2) + " / Y " + sel.y.toFixed(2) +
              (config.journalEnabled ? (written ? " — journal CSV mis à jour." : " — ÉCHEC d'écriture du journal !") : "."),
              written || !config.journalEnabled ? "info" : "error");
        newMeasure();
    }

    function journalPath() {
        if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath) {
            return "";
        }
        return qgisProject.homePath + "/" + config.journalRelativePath;
    }

    function appendJournal(row) {
        var path = journalPath();
        if (path === "") {
            log("Journal : aucun projet ouvert.");
            return false;
        }
        if (typeof FileUtils === "undefined" || typeof FileUtils.writeFileContent !== "function") {
            log("Journal : FileUtils.writeFileContent indisponible dans cette version de QField.");
            return false;
        }
        var existing = "";
        try {
            if (FileUtils.fileExists(path)) {
                existing = Journal.utf8Decode(FileUtils.readFileContent(path));
            }
        } catch (e) {
            log("Journal : lecture impossible (" + e + "), création d'un nouveau contenu.");
        }
        var text = Journal.appendRow(existing, row, config.csvSeparator);
        var ok = false;
        try {
            ok = FileUtils.writeFileContent(path, Journal.utf8Encode(text, existing === ""));
        } catch (e2) {
            log("Journal : écriture impossible : " + e2);
            ok = false;
        }
        if (!ok) {
            log("Journal : échec d'écriture " + path);
        }
        return ok;
    }

    /*
     * PHASE 4 (non incluse dans ce prototype) : création de l'entité dans la
     * couche cible configurée, puis ouverture du formulaire QField standard.
     * Les API sont identifiées : FeatureUtils.createFeature(layer, geometry),
     * iface.findItemByObjectName('overlayFeatureFormDrawer'), featureModel.feature.
     */
    function createFeatureHook(record) {
        return false;
    }

    function copySelectedToClipboard() {
        if (!selectedCandidate) {
            return;
        }
        var t = selectedCandidate.x.toFixed(3) + (config.csvSeparator === "," ? ";" : ",") + selectedCandidate.y.toFixed(3);
        if (typeof platformUtilities !== "undefined" && platformUtilities.copyTextToClipboard) {
            platformUtilities.copyTextToClipboard(t);
            toast("Copié : " + t + " (" + calcCrsAuthid + ")", "info");
        }
    }

    /* ======================================================================
     *  Recommencer
     * ====================================================================== */
    function requestRestart() {
        if (!stationA && !stationB && d1Text === "" && d2Text === "") {
            newMeasure();
            return;
        }
        confirmDialog.ask("Recommencer ?", "Les positions A, B et les distances saisies seront effacées.",
                          "EFFACER", function () { newMeasure(); });
    }

    function newMeasure() {
        stationA = null;
        stationB = null;
        d1Text = "";
        d2Text = "";
        calcCrsAuthid = "";
        calcCrsOrigin = "";
        scaleFactor = NaN;
        sessionRestored = false;
        invalidateResult();
        saveSession();
        panel.resetView();
    }

    function openSettings() {
        settingsDialog.openWith(config);
    }

    /* Appelé par QField (Paramètres > Plugins > bouton de configuration du plugin) */
    function configure() {
        openSettings();
    }
}
