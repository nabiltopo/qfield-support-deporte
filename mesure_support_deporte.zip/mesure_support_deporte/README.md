# Mesurer support déporté — plugin QField (v0.5.0, Phases 1 à 4 + altimétrie)

Levé déporté de supports électriques MT/BT (poteaux, potelets, consoles) par
**trilatération 2 points** : deux positions GNSS RTK (A, B) prises depuis le
véhicule ou l'accotement, et deux distances télémètre **saisies à la main**
(D1, D2) vers le pied du même support.

| Phase | Contenu | État |
|---|---|---|
| 1 — Analyse | architecture, API QField vérifiées, risques | ✅ livrée (§1) |
| 2 — Prototype mathématique | moteur JS pur + 10 tests obligatoires + compléments | ✅ |
| 3 — Plugin minimal | prise A/B, D1/D2, calcul, P1/P2 sur carte, qualité, journal CSV, simulation | ✅ testé sur téléphone (27/09/2026) |
| 4 — Création de l'entité | support créé dans **EL_SUPPORT** + formulaire QField, champs pré-remplis, journal lié par `ID_TERRAIN` | ✅ |
| Altimétrie (v0.5) | réduction des distances **inclinées** + **Z du support** (SU_Z, EL_COOR_Z) | ✅ 133 tests unitaires + 55 vérifications dans un QField simulé |
| 5–7 — Durcissement, UX, livraison finale | | ⏳ |

Pas de Bluetooth dans cette version : l'architecture le prévoit (`DistanceProvider`).

---

## 0 bis. Nouveautés v0.5.0 — Z du support et distances inclinées

**Le problème.** Un télémètre simple mesure la distance **le long de la visée**, depuis la main de l'opérateur (environ 1,30 m au-dessus du sol en véhicule) jusqu'au pied du poteau. Cette distance **inclinée** est plus longue que la distance horizontale, par exemple de 10,6 cm pour 8 m mesurés. Sans correction, le poteau est placé trop loin, de 5 à 15 cm, **toujours dans le même sens**.

**La méthode** (`js/altimetry.js`) :

1. **Z du support**, interpolé le long de l'axe A-B :
   `ZP = ZA + t·(ZB − ZA)`, avec `t = a/d`, la position du pied de la perpendiculaire (0 = A, 1 = B).
   P1 et P2 ont le même t : le Z ne dépend pas du côté choisi.
2. **Réduction à l'horizontale** de chaque distance :
   `Δh = (Z station + hauteur de visée) − ZP` puis `D = √(S² − Δh²)`.
3. Comme ZP dépend de D, le calcul est répété jusqu'à ce que le Z ne bouge plus de 0,5 mm, en 2 ou 3 passes.
4. Si l'altitude GNSS manque, le terrain est supposé plat (Δh = hauteur de visée) et le Z n'est pas calculé.

**Résultats des tests** (route en pente de 4 %, lectures au cm) : poteau placé à **4 mm** près, Z retrouvé au mm près. Sans la réduction, l'erreur aurait été de **14 cm**.

**Ce qui est écrit dans EL_SUPPORT** : `SU_Z` (Cote terrain) et `EL_COOR_Z` reçoivent le Z du support. `EL_COOR_Z` recevait auparavant l'altitude du téléphone. Le commentaire mentionne « Z≈… m interpolé ».

Réglages, dans ⚙ → *Télémètre* :

| Paramètre | Défaut | Conseil |
|---|---|---|
| Distance affichée par le télémètre | INCLINEE | HORIZONTALE uniquement si votre télémètre affiche déjà la distance horizontale |
| Hauteur du télémètre au-dessus du sol | 1,30 m | environ 1,30 m assis en véhicule, environ 1,50 m debout ; à mesurer une fois |
| Pente A-B maximale | 15 % | au-delà, le Z est signalé « à contrôler » |

**Conditions pour que le Z soit juste** :
- Dans QField, la **hauteur d'antenne** (*Paramètres → Positionnement*) doit être celle de l'antenne au-dessus du **sol**. ZA et ZB doivent être des altitudes du sol.
- Le terrain doit être régulier entre la route et le pied du poteau. Un fossé ou un talus n'est pas détecté : le Z est une **estimation**, précise à quelques centimètres sur terrain régulier.
- L'effet d'une hauteur de visée fausse est faible : 20 cm d'erreur sur la hauteur ne décale le poteau que d'environ 3 cm à 8 m.

**Journal CSV** : il gagne les colonnes `mode_distance`, `hauteur_visee`, `D1_horizontale`, `D2_horizontale`, `Z_support` et `mode_Z`. Si un ancien journal existe avec d'autres colonnes, il n'est **jamais écrasé** : les nouvelles mesures vont dans `journal_trilateration_<n>col.csv`.

> Si vos paramètres ont été enregistrés avec la v0.4, la ligne *Champs pré-remplis* ne contient pas encore le Z. Touchez **DÉFAUTS** puis **ENREGISTRER**, ou ajoutez `;SU_Z={Z_P};EL_COOR_Z={Z_P}`.

## 0. Nouveautés v0.4.0 — Phase 4 : création du support

Quand vous touchez **VALIDER SUPPORT** :

1. Le point choisi (P1 ou P2) est créé dans la couche **EL_SUPPORT** (`data.gpkg`, EPSG:26191) du projet *SRM Nador-Driouch*.
2. Le **formulaire QField standard** s'ouvre avec ses onglets, listes et photos. Vous complétez Type, Réseau, Commune… et enregistrez comme d'habitude.
3. Le plugin pré-remplit :
   - `SU_MODE_LOCALISATION` = **Triangulé**, une valeur qui existe déjà dans la liste du projet ;
   - `SU_COMMENTAIRE` = un résumé de traçabilité, par exemple :
     `Levé déporté trilatération 2 pts : D1 11.26 m, D2 8.45 m, AB 14.60 m, P2 droite, qualité BON (±14 cm indicatif), GNSS RTK FIX/RTK FIX, réf. TRI_…`
4. Les **valeurs par défaut du projet sont conservées** : `SU_IDENT`, `ID_TERRAIN` (uuid), `EL_COOR_X/Y`, `SU_MATRICULE_CREA`, `AGENTINTEGRATEUR`. Le contrôle anti-doublon à 1 m reste actif.
5. **Enregistré** : une ligne est ajoutée au journal CSV avec `entite_creee = OUI` et `id_entite` = l'`ID_TERRAIN` du support, ce qui fait le lien entre la mesure et l'entité. La couche active d'avant est rétablie et la mesure est remise à zéro.
6. **Annulé** : aucun support n'est créé et rien n'est écrit dans le journal. **La mesure est conservée** : vous pouvez revalider ou choisir l'autre point.

Réglages, dans ⚙ → *Création du support* (en haut de l'écran) :

| Paramètre | Défaut | Rôle |
|---|---|---|
| Créer le support… | Oui | Non = comportement v0.3 (journal seul) |
| Couche cible | EL_SUPPORT | liste des couches de points modifiables du projet |
| Champs pré-remplis | `SU_MODE_LOCALISATION=Triangulé;SU_COMMENTAIRE={resume};SU_Z={Z_P};EL_COOR_Z={Z_P}` | `CHAMP=valeur;…`. Un champ absent de la couche est ignoré, sans erreur |
| Champ identifiant | ID_TERRAIN | valeur reprise dans le journal (`id_entite`) |
| Remplir les champs de traçabilité | Oui | remplit `methode_leve`, `XA`, `D1`, `baseline_AB`… **si** la couche possède ces champs |

**Jetons disponibles** dans les valeurs : `{Z_P} {D1h} {D2h} {mode_Z} {mode_distance} {D1} {D2} {AB} {X} {Y} {XA} {YA} {ZA} {XB} {YB} {ZB} {Z_moy} {choix} {cote} {qualite} {qualite_label} {qualite_A} {qualite_B} {precision_A} {precision_B} {residu} {angle} {incertitude} {methode} {mode_calcul} {id_mesure} {date} {operateur} {crs} {resume}`.
`{D1}`/`{D2}` sont les distances saisies ; `{D1h}`/`{D2h}` les distances horizontales utilisées dans le calcul.

> Le plugin applique ses valeurs **après** les valeurs mémorisées de QField : même si l'opérateur a mémorisé « Levé topographique » pour `SU_MODE_LOCALISATION`, un support déporté est bien marqué « Triangulé ».

### Mettre à jour le plugin sur le téléphone
1. Remplacez `mesure_support_deporte.zip` dans le dossier du dépôt GitHub par la nouvelle version, **sous le même nom**.
2. GitHub Desktop → *Commit to main* → **Push origin**.
3. QField → ⚙ Paramètres → Plugins : réinstallez avec **le même lien ou le même QR code**. L'ancienne version est remplacée ; vos paramètres sont conservés et les nouveaux prennent leur valeur par défaut.

---

## 1. Phase 1 — Analyse technique

### Architecture retenue
**Plugin d'application QField en QML/JavaScript** (mécanisme officiel, QField ≥ 3.x ;
développé et vérifié contre le code source de **QField 4.3.3**, publié le 17/09/2026).

- Installé une fois pour tous les projets (zip).
- Le calcul est en **JavaScript pur** (`js/*.js`), sans dépendance à QField, donc testable sous Node.js.
- Les expressions QGIS ne permettent ni l'interaction GNSS en deux temps ni le choix graphique entre P1 et P2 : elles ont été écartées.

### Outil natif QField existant
QField 4.x possède un outil COGO **« Circles Intersection »** en numérisation, qui peut utiliser la position courante.
Il ne couvre pas le besoin de reconnaissance :

- il calcule dans les unités du CRS de la carte, donc il est faux sur un projet en degrés ;
- il ne conserve ni la précision GNSS ni le statut RTK de A et B ;
- il n'affiche rien si les cercles ne se coupent pas : pas d'ajustement, pas de diagnostic ;
- il ne donne aucun indicateur de qualité et ne produit aucune traçabilité.

### API QField utilisées (toutes vérifiées dans le code source)
| Besoin | API |
|---|---|
| Position GNSS | `iface.findItemByObjectName('positionSource')` → `.active`, `.projectedPosition`, `.coordinateTransformer.destinationCrs`, `.positionInformation` (`quality` GGA, `hacc`, `haccValid`, `satellitesUsed`, `utcDateTime`, `qualityDescription`) |
| Carte | `iface.mapCanvas().mapSettings` (`destinationCrs`, `center`, `setExtent()`), `MapToScreen` (affichage des candidats) |
| CRS | `CoordinateReferenceSystemUtils.fromDescription()`, `GeometryUtils.reprojectPoint()` (contexte de transformation du projet), `GeometryUtils.point()` |
| Interface | `iface.addItemToPluginsToolbar()`, `iface.mainWindow().contentItem`, `displayToast()`, `QfToolButton`, `Theme` |
| Configuration | `settings.value()/setValue()` ; `configure()` appelé par QField (bouton Configurer du plugin) |
| Journal | `FileUtils.readFileContent()/writeFileContent()` : écriture **limitée au dossier du projet** |
| Phase 4 | `ProjectUtils.mapLayers()`, `layer.fields.names`, `layer.wkbType()`, `FeatureUtils.createBlankFeature()`, `overlayFeatureFormDrawer.featureModel` (`resetAttributes(true)`, `updateAttributesFromFeature()`), `dashBoard.activeLayer`, `LayerUtils.createFeatureIteratorFromExpression()` (contrôle enregistré/annulé), `LayerUtils.isFeatureAdditionLocked()` |

### Risques identifiés
1. **Projet en CRS géographique** : le calcul se fait dans un CRS métrique de repli (EPSG:26191 par défaut, sinon UTM automatique). Ce cas est testé.
2. **Facteur d'échelle de la projection** : en EPSG:26191, k ≈ +560 ppm à Tanger (1,1 cm sur 20 m) et ≈ −290 ppm à Rabat/Fès. Le plugin applique `D_grille = k × D_mesurée` (option activée par défaut) ; ce point a été validé contre PROJ.
3. **Datum Merchich ↔ WGS84** (paramètre `towgs84`) : décalage absolu de quelques mètres et aller-retour non exact (≈ 1,8 mm, même comportement dans PROJ et QGIS). A, B et P subissent le **même** décalage, donc la géométrie relative est inchangée (vérifié à 0,0000 mm).
4. **Qualité de la mesure humaine** : pied de poteau visé, inversion D1/D2, faute de frappe. Ces erreurs sont détectées par la cohérence des cercles.
5. **Clavier Android** qui masque le panneau : le panneau passe en haut de l'écran quand le clavier est ouvert.

---

## 2. Architecture et arborescence

```
mesure_support_deporte/
├── metadata.txt              métadonnées QField (nom, version, icône)
├── icon.svg                  icône du plugin
├── main.qml                  point d'entrée + CONTRÔLEUR (état, orchestration)
├── MsdGnssService.qml        Module 1 — gestion GNSS (lecture positionSource)
├── MsdCrsService.qml         CRS de calcul, transformations, facteur d'échelle
├── MsdPanel.qml              Module 4 — panneau principal (complet / réduit)
├── MsdStationCard.qml        carte « POINT A / POINT B » + saisie D1/D2
├── MsdMapOverlay.qml         Module 4 — A, B, cercles, P1/P2 tactiles sur la carte
├── MsdCandidateButtons.qml   « Sélectionner le support »
├── MsdResultActions.qml      VALIDER SUPPORT / COPIER
├── MsdQualityBadge.qml       🟢 BON / 🟠 À CONTRÔLER / 🔴 REPRENDRE
├── MsdGnssBadge.qml          état GNSS en direct
├── MsdSettingsDialog.qml     Module 6 — écran Paramètres (généré depuis le schéma)
├── MsdConfirmDialog.qml      confirmations (écrasement A/B, recommencer…)
├── MsdBigButton.qml / MsdIconButton.qml   boutons 56 px (gants, soleil)
├── js/
│   ├── trilateration.js      Module 2 — intersection de 2 cercles + moindres carrés (V2)
│   ├── geodesy.js            Vincenty WGS84, facteur d'échelle local
│   ├── quality.js            Module 3 — contrôle qualité, indicateur
│   ├── config.js             Module 6 — défauts, schéma, validation
│   ├── distance_providers.js DistanceProvider : Manual (V1), Bluetooth (réservé V2)
│   ├── constraints.js        alignement / projection sur axe (préparé, non branché)
│   ├── feature_mapping.js    Module 5 — jetons, champs pré-remplis, WKT, contrôle de création
│   ├── altimetry.js          Z du support (interpolation A-B) + réduction des distances inclinées
│   └── journal.js            CSV de traçabilité, UTF-8, session
└── tests/
    ├── run_tests.js          tests unitaires Node (100 vérifications)
    ├── qmljs_loader.js       charge les .js QML dans Node
    ├── crs_check.py          contrôle EPSG:26191 avec PROJ
    ├── resultats_tests.txt / resultats_crs_check.txt
    └── qml_harness/          QField simulé (PySide6) : 5 scénarios, captures PNG
```

**Flux** : `MsdStationCard` → `controller.requestCapture('A')` → `MsdGnssService.snapshot()`
→ `MsdCrsService.transform()` vers le CRS de calcul → `controller.compute()`
→ `Geodesy.groundToGrid()` → `Trilat.intersectCircles()` → `Quality.evaluate()`
→ `overlayData` (carte) + panneau réduit → sélection de P1/P2 → `validate()` → journal CSV.

**Préparation des évolutions**
- *Bluetooth* : `BluetoothDistanceProvider` doit renvoyer le même objet `Measurement` (`value`, `azimuthDeg`, `inclinationDeg`) ; le moteur n'a pas à changer.
- *3ᵉ mesure / moindres carrés* : `Trilat.trilaterateLeastSquares()` est déjà implémentée et testée.
- *Alignement* : `constraints.js` (projection sur segment/polyligne, départage de P1/P2) est implémenté et testé ; il reste à le brancher dans l'interface.
- *Création d'entité* : `startFeatureCreation()` / `finalizeFeature()` dans `main.qml` + `js/feature_mapping.js`.

---

## 3. Moteur de calcul (Module 2)

Formules du cahier des charges, avec les protections suivantes :
- validation des entrées (distances > 0, points valides, A ≠ B à 1 µm près) ;
- **le test d'existence est fait avant la racine carrée** : incohérence `gap = max(d − (D1+D2), |D1−D2| − d)` ;
- `h = √((D1−a)(D1+a))`, forme factorisée plus stable numériquement ;
- **P1 = à GAUCHE** du sens A→B, **P2 = à DROITE** ; l'opérateur choisit en connaissant son sens de déplacement.

| Cas | Condition | Résultat | Statut |
|---|---|---|---|
| 1 | cercles sécants | P1, P2 | BON si la géométrie et le GNSS sont bons |
| — | tangence (h < 1 mm) | P unique sur l'axe AB | À CONTRÔLER |
| 2 | 0 < gap ≤ tolérance | ajustement pondéré des rayons (moindres carrés au 1ᵉʳ ordre) → P unique | À CONTRÔLER |
| 3 | gap > tolérance | aucun point, message explicite (D1+D2 < AB ou \|D1−D2\| > AB) | REPRENDRE |

Tolérance = `k × √(σ1² + σ2²)`, bornée par [min ; max], avec `σi² = σtélémètre² + σGNSS_i²` (valeurs configurables).

**Indicateur de géométrie** : angle d'intersection γ au support, facteur `√2 / sin γ`.
« L'incertitude indicative » vaut ce facteur × σ distance. C'est **un indicateur de contrôle terrain, pas une précision garantie**.
Le test Monte-Carlo n°9 montre cependant que le modèle est cohérent : RMSE simulé 7,4 cm pour 7,4 cm annoncés.

---

## 4. Installation

### A. Depuis une URL (méthode officielle QField)
1. Déposez `mesure_support_deporte-v0.3.0.zip` à une adresse HTTPS en téléchargement direct (release GitHub, serveur web interne…).
2. Dans QField : **tableau de bord latéral → ⚙ Paramètres → Plugins → Installer un plugin depuis une URL**, puis collez l'URL.
3. Activez le plugin avec l'interrupteur et **accordez la permission** demandée au premier lancement.
4. Une icône bleue (deux cercles et un poteau) apparaît dans la barre des plugins.

### B. Copie manuelle (sans serveur)
1. Décompressez le zip ; vous obtenez le dossier `mesure_support_deporte/`.
2. Copiez-le dans le dossier `plugins/` du répertoire applicatif de QField. Sur Android, il s'agit en général de `Android/data/ch.opengis.qfield/files/QField/plugins/` ; sur PC, de `…/QField Documents/QField/plugins/`.
3. Redémarrez QField, puis activez le plugin dans **Paramètres → Plugins**.

> Le chemin exact du répertoire applicatif dépend de l'appareil : vérifiez-le dans *Paramètres → Plugins* ou avec un gestionnaire de fichiers.

### Récepteur Oscar RTK
Rien à configurer dans le plugin : il lit la position que QField reçoit déjà
(*Paramètres → Positionnement*, récepteur externe, correction NTRIP). Vérifiez que QField affiche bien **RTK FIX** avant de commencer.

---

## 5. Utilisation sur le terrain

1. Touchez l'icône du plugin : le panneau « SUPPORT DÉPORTÉ » s'ouvre en bas de l'écran, la carte reste visible.
2. **PRENDRE POSITION A** (le bandeau GNSS doit être vert, RTK FIX), puis visez le **pied** du poteau au télémètre et saisissez **D1** (virgule ou point acceptés).
3. Avancez de **10 à 20 m** (la baseline s'affiche en direct : rouge < 2 m, orange < 5 m), puis **PRENDRE POSITION B** et saisissez **D2**. La touche Entrée du clavier lance le calcul.
4. **CALCULER** : le panneau se réduit, la carte cadre A, B, les cercles, P1 (violet, à gauche) et P2 (orange, à droite), avec une flèche bleue pour le sens A→B.
5. **Touchez le bon support sur la carte** ou sur les boutons P1 / P2.
6. **VALIDER SUPPORT** : le support est créé dans EL_SUPPORT et le formulaire QField s'ouvre (voir §0). Après enregistrement, une ligne est ajoutée au journal CSV et la mesure est remise à zéro pour le support suivant. **COPIER** met X,Y dans le presse-papier.

Sécurités : confirmation avant de remplacer A ou B et avant RECOMMENCER, confirmation demandée si la qualité est « À CONTRÔLER », validation bloquée si elle est « REPRENDRE », saisie numérique contrôlée. Les mesures en cours sont conservées si QField change de fenêtre ou redémarre.

**Paramètres** : bouton ⚙ du panneau, **appui long** sur l'icône du plugin, ou bouton *Configurer* dans la liste des plugins de QField.

### Journal CSV
`<dossier du projet>/trilateration/journal_trilateration.csv` (UTF-8 avec BOM, séparateur `;`) contient une ligne par support validé, avec :
`id_mesure, date_mesure, operateur, methode_leve (TRILATERATION_2_POINTS), mode_calcul, crs_calcul, XA, YA, ZA, qualite_A, precision_A, XB…, D1, D2, baseline_AB, cas_geometrique, X_P1…Y_P2, choix, X_calc, Y_calc, residu, correction_D1/D2, angle_intersection, incertitude_indicative, qualite_trilateration, messages, X_ref, Y_ref`.

Les colonnes **X_ref / Y_ref** sont vides : complétez-les avec le levé RTK direct au pied du support pour le protocole de validation.

---

## 6. Procédure de test

### Sur PC, sans QField
```bash
node tests/run_tests.js                                          # moteur + Phase 4 + altimétrie : 133 vérifications
pip install pyproj && python3 tests/crs_check.py                 # EPSG:26191 contre PROJ
pip install PySide6 pyproj
QT_QPA_PLATFORM=offscreen python3 tests/qml_harness/harness.py   # plugin dans un QField simulé
```
Les résultats de référence sont dans `tests/resultats_*.txt` ; les captures d'écran dans `tests/qml_harness/out/`.

### Dans QField, sans GNSS (QField Windows/Linux/macOS ou téléphone au bureau)
1. ⚙ → **Mode simulation = Oui** → Enregistrer. Le bandeau devient violet (« MODE SIMULATION »).
2. Bouton **EXEMPLE** puis **CALCULER** : le résultat attendu est BON, avec AB = 14,60 m, D1 = 11,26 m et D2 = 8,45 m.
3. Source « CENTRE » : déplacez la carte, puis PRENDRE A ; déplacez-la de nouveau, puis PRENDRE B. Source « XY » : saisissez les coordonnées dans le CRS de calcul.

### Validation terrain (environ 20 poteaux, télémètre actuel + Oscar RTK)
Pour chaque poteau :
1. Levé RTK classique au pied du support, à reporter dans X_ref / Y_ref.
2. Levé déporté avec le plugin, en variant la baseline (5, 10, 20 m) et la distance au support.
3. Analyse du CSV : erreur X, erreur Y, erreur planimétrique, moyenne, RMSE, écart-type, maximum.

Notez aussi le modèle du télémètre et sa précision annoncée, pour régler `telemeterSigma`.

---

## 7. Débogage

- **Journal QField** : *Paramètres → Journal des messages*. Le plugin y écrit en préfixant ses lignes par `[Support déporté]` (CRS, calculs, validations, erreurs d'écriture).
- **Le plugin ne se charge pas** : le journal indique alors `Plugin Manager` avec la ligne QML fautive. Vérifiez que le zip contient bien `mesure_support_deporte/main.qml`.
- **« Positionnement désactivé » / « Position GNSS non valide »** : activez le GNSS dans QField, attendez une position valide, ou passez en mode simulation.
- **Mauvais côté ou P1/P2 incohérents** : vérifiez que A a bien été pris **avant** B dans le sens du déplacement. La flèche bleue sur la carte indique ce sens.
- **REPRENDRE systématique** : contrôlez le pied de poteau visé, une éventuelle inversion D1/D2, et la tolérance (`telemeterSigma`, `nearMissK`).
- **« ÉCHEC d'écriture du journal »** : le projet doit être ouvert depuis un dossier accessible en écriture ; QField refuse d'écrire hors du dossier du projet.
- **Réinitialiser** : ⚙ → DÉFAUTS → ENREGISTRER.

---

## 8. Limitations connues (v0.3.0)

- **Z du support** : c'est une interpolation entre A et B, qui ne voit ni fossé ni talus. Le calcul exact demande l'**angle de visée**, fourni par un télémètre avec inclinomètre (V2) : `ZP = Zi + hv − S·sin(α)`, avec contrôle croisé entre A et B.
- **Phase 4 vérifiée dans un QField simulé** qui reproduit fidèlement `QfFeatureModel` 4.3.3 (valeurs par défaut, valeurs mémorisées, champs « création seule »). Elle reste à confirmer sur le téléphone, avec votre projet.
- **Prise instantanée** (une seule époque GNSS) : il n'y a pas de moyennage. Il faut attendre un RTK FIX stable avant d'appuyer.
- **Le choix de P1/P2 reste humain** : le plugin ne peut pas savoir de quel côté se trouve le poteau. Les options sont une présélection configurable du côté, puis l'alignement (V2).
- **Cadrage automatique** : calculé pour une carte non tournée. Si la carte est tournée, les points restent affichés correctement, mais le cadrage peut être imparfait.
- **Incertitude indicative** : modèle simplifié (erreurs indépendantes, sans erreur de pointé du pied de poteau). Ce n'est pas une précision topographique.
- **Test en conditions réelles** : le plugin a été vérifié dans un QField simulé (Qt 6.11) reproduisant l'API 4.3.3, pas encore sur un téléphone Android. Le comportement du clavier Android et la synchronisation du journal CSV avec QFieldCloud restent à confirmer sur l'appareil.

## 9. Pistes d'évolution

2. **Moyennage GNSS** de A et B sur N époques, avec l'écart-type en indicateur.
3. **Troisième mesure de contrôle** : C + D3 avec `trilaterateLeastSquares()` (redondance, sigma0), ce qui élimine l'ambiguïté P1/P2.
4. **Alignement MT** : départage automatique de P1/P2 et projection optionnelle sur l'axe (fonctions de `constraints.js` déjà prêtes).
5. **V2 Bluetooth** : `BluetoothDistanceProvider` (distance, azimut, inclinaison) permettant le mode à une seule station (GNSS + distance + azimut) et un **Z mesuré** plutôt qu'interpolé.
6. Script d'analyse du CSV de validation (RMSE, histogrammes) et réglage des seuils à partir des 20 poteaux.
