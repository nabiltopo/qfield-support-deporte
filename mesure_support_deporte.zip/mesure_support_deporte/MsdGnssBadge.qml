/*
 * Mesurer support déporté — état GNSS en direct (ou bandeau SIMULATION)
 *   GNSS : RTK FIX · 1.4 cm · 21 sat
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: badge

    property var gnss: null
    property bool simulation: false

    implicitHeight: row.implicitHeight + 14
    radius: 8
    color: simulation ? "#6A1B9A" : (gnss ? gnss.statusColor : "#C0392B")

    RowLayout {
        id: row
        anchors.fill: parent
        anchors.margins: 7
        spacing: 10
        Label {
            text: badge.simulation ? "MODE SIMULATION" : "GNSS " + (badge.gnss ? badge.gnss.qualityLabel : "—")
            color: "white"
            font.pixelSize: 18
            font.bold: true
        }
        Label {
            visible: !badge.simulation && badge.gnss !== null && badge.gnss.valid
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignRight
            elide: Text.ElideRight
            text: badge.gnss ? "± " + badge.gnss.accuracyText + (badge.gnss.satellites > 0 ? " · " + badge.gnss.satellites + " sat" : "") : ""
            color: "white"
            font.pixelSize: 16
            font.bold: true
        }
        Label {
            visible: badge.simulation
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignRight
            text: "positions sans GNSS"
            color: "white"
            font.pixelSize: 14
        }
    }
}
