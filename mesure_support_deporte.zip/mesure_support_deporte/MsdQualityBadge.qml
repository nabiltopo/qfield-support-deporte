/*
 * Mesurer support déporté — indicateur qualité
 *   🟢 BON   /   🟠 À CONTRÔLER   /   🔴 REPRENDRE LA MESURE
 * La forme (●, ▲, ■) double la couleur pour les daltoniens et le plein soleil.
 * En mode réduit, un toucher affiche le détail.
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: qb

    property var evaluation: null
    property bool compactStyle: false
    readonly property string status: evaluation ? evaluation.status : ""
    readonly property int alertCount: {
        if (!evaluation) {
            return 0;
        }
        var n = 0;
        for (var i = 0; i < evaluation.messages.length; i++) {
            if (evaluation.messages[i].level !== "INFO") {
                n++;
            }
        }
        return n;
    }

    signal clicked()

    visible: evaluation !== null
    implicitHeight: Math.max(compactStyle ? 50 : 60, row.implicitHeight + 12)
    radius: 8
    color: status === "BON" ? "#1B7F37" : (status === "A_CONTROLER" ? "#D35400" : "#C0392B")

    RowLayout {
        id: row
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 14
        anchors.rightMargin: 12
        spacing: 12
        Text {
            text: qb.status === "BON" ? "●" : (qb.status === "A_CONTROLER" ? "▲" : "■")
            color: "white"
            font.pixelSize: qb.compactStyle ? 24 : 30
        }
        Label {
            Layout.fillWidth: true
            text: qb.evaluation ? qb.evaluation.label : ""
            color: "white"
            font.pixelSize: qb.compactStyle ? 20 : 22
            font.bold: true
            wrapMode: Text.WordWrap
        }
        Label {
            visible: qb.compactStyle
            text: (qb.alertCount > 0 ? qb.alertCount + " msg " : "") + "détail ›"
            color: "white"
            font.pixelSize: 15
            font.bold: true
        }
    }

    MouseArea {
        anchors.fill: parent
        enabled: qb.compactStyle
        onClicked: qb.clicked()
    }
}
