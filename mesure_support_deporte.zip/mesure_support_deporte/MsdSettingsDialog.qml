/*
 * Mesurer support déporté — Module 6 : écran Paramètres
 * Généré à partir de Config.SCHEMA : ajouter un paramètre dans js/config.js
 * suffit à le rendre éditable ici. Valeurs validées par Config.merge().
 * Accès : bouton ⚙ du panneau, ou appui long sur l'icône du plugin.
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import "js/config.js" as Config

Popup {
    id: dlg

    property var controller: null
    property var draft: ({})

    modal: true
    focus: true
    closePolicy: Popup.CloseOnEscape
    width: parent ? Math.min(parent.width - 16, 620) : 400
    height: parent ? parent.height - (Qt.inputMethod.visible ? parent.height * 0.4 : 32) : 600
    x: parent ? (parent.width - width) / 2 : 0
    y: 16
    padding: 0

    background: Rectangle {
        color: "white"
        radius: 10
        border.color: "#212121"
        border.width: 2
    }

    function openWith(cfg) {
        draft = JSON.parse(JSON.stringify(cfg));
        repeater.model = [];
        repeater.model = Config.SCHEMA;
        open();
    }

    function setValue(key, value) {
        draft[key] = value;
    }

    contentItem: ColumnLayout {
        spacing: 0

        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 52
            color: "#212121"
            radius: 8
            Label {
                anchors.verticalCenter: parent.verticalCenter
                anchors.left: parent.left
                anchors.leftMargin: 14
                text: "PARAMÈTRES — support déporté"
                color: "white"
                font.pixelSize: 18
                font.bold: true
            }
        }

        Flickable {
            id: flick
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            contentWidth: width
            contentHeight: form.implicitHeight + 20
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar { width: 10 }

            ColumnLayout {
                id: form
                x: 14
                y: 10
                width: flick.width - 28
                spacing: 6

                Repeater {
                    id: repeater
                    model: []
                    delegate: ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        readonly property var entry: modelData
                        readonly property bool newGroup: index === 0 || Config.SCHEMA[index - 1].group !== modelData.group

                        Label {
                            visible: newGroup
                            Layout.topMargin: 12
                            text: modelData.group.toUpperCase()
                            font.pixelSize: 15
                            font.bold: true
                            color: "#1565C0"
                        }
                        Label {
                            Layout.fillWidth: true
                            text: modelData.label
                            wrapMode: Text.WordWrap
                            font.pixelSize: 15
                            color: "#111111"
                        }
                        TextField {
                            visible: modelData.type === "number" || modelData.type === "string"
                            Layout.fillWidth: true
                            text: visible ? String(dlg.draft[modelData.key]) : ""
                            font.pixelSize: 18
                            inputMethodHints: modelData.type === "number" ? (Qt.ImhFormattedNumbersOnly | Qt.ImhNoPredictiveText) : Qt.ImhNoPredictiveText
                            onTextEdited: dlg.setValue(modelData.key, text)
                        }
                        Switch {
                            visible: modelData.type === "bool"
                            checked: dlg.draft[modelData.key] === true
                            text: checked ? "Oui" : "Non"
                            font.pixelSize: 17
                            onToggled: dlg.setValue(modelData.key, checked)
                        }
                        ComboBox {
                            visible: modelData.type === "enum"
                            Layout.fillWidth: true
                            model: modelData.type === "enum" ? modelData.options : []
                            currentIndex: modelData.type === "enum" ? Math.max(0, modelData.options.indexOf(dlg.draft[modelData.key])) : -1
                            font.pixelSize: 17
                            onActivated: function (i) { dlg.setValue(modelData.key, modelData.options[i]); }
                        }
                    }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.margins: 10
            spacing: 8
            MsdBigButton {
                Layout.fillWidth: true
                text: "DÉFAUTS"
                fontSize: 16
                fillColor: "#ECEFF1"
                textColor: "#111111"
                onClicked: dlg.openWith(Config.defaults())
            }
            MsdBigButton {
                Layout.fillWidth: true
                text: "ANNULER"
                fontSize: 16
                fillColor: "#ECEFF1"
                textColor: "#111111"
                onClicked: dlg.close()
            }
            MsdBigButton {
                Layout.fillWidth: true
                text: "ENREGISTRER"
                fontSize: 16
                fillColor: "#1B7F37"
                onClicked: {
                    Qt.inputMethod.commit();
                    dlg.controller.saveConfig(dlg.draft);
                    dlg.close();
                }
            }
        }
    }
}
