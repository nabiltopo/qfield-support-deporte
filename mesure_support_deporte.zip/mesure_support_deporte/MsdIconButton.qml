/*
 * Mesurer support déporté — bouton d'en-tête (48 x 48, blanc sur fond sombre)
 */
import QtQuick
import QtQuick.Controls

AbstractButton {
    id: btn
    implicitWidth: 48
    implicitHeight: 48
    background: Rectangle {
        radius: 6
        color: btn.down ? "#424242" : "transparent"
    }
    contentItem: Text {
        text: btn.text
        color: "white"
        font.pixelSize: 22
        font.bold: true
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
    }
}
