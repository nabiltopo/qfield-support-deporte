/*
 * Mesurer support déporté — Module 4 : affichage temporaire sur la carte
 *
 *  - A et B (carrés bleus) et leurs cercles de rayon D1 / D2 ;
 *  - candidats P1 (gauche) / P2 (droite) : grandes cibles tactiles ;
 *    toucher un candidat le sélectionne ;
 *  - supports déjà validés pendant la session (points gris numérotés).
 *
 * Aucune couche n'est créée : ce sont des éléments QML posés sur le canevas,
 * positionnés avec MapToScreen (API QField), qui suit zoom, déplacement et
 * rotation de la carte.
 */
import QtQuick
import org.qfield
import org.qgis

Item {
    id: overlay

    property var controller: null
    readonly property var od: controller ? controller.overlayData : null
    readonly property var mapSettings: controller && controller.mapCanvas ? controller.mapCanvas.mapSettings : null

    readonly property color stationColor: "#1565C0"
    readonly property color p1Color: "#8E24AA"   // violet : gauche
    readonly property color p2Color: "#EF6C00"   // orange : droite
    readonly property color axisColor: "#00897B"
    readonly property color selectedColor: "#1B7F37"

    /* ---------------- Supports validés pendant la session ---------------- */
    Repeater {
        model: overlay.od ? overlay.od.validated : []
        delegate: Item {
            MapToScreen {
                id: vScreen
                mapSettings: overlay.mapSettings
                mapPoint: GeometryUtils.point(modelData.mapX, modelData.mapY)
            }
            x: vScreen.screenPoint.x - 11
            y: vScreen.screenPoint.y - 11
            width: 22
            height: 22
            Rectangle {
                anchors.fill: parent
                radius: 11
                color: "#607D8B"
                border.color: "white"
                border.width: 2
            }
            Text {
                anchors.centerIn: parent
                text: modelData.label
                color: "white"
                font.pixelSize: 11
                font.bold: true
            }
        }
    }

    /* ---------------- Stations A / B + cercles ---------------- */
    Repeater {
        model: overlay.od ? overlay.od.stations : []
        delegate: Item {
            id: stationItem
            anchors.fill: parent

            MapToScreen {
                id: centerScreen
                mapSettings: overlay.mapSettings
                mapPoint: GeometryUtils.point(modelData.mapX, modelData.mapY)
            }
            MapToScreen {
                id: edgeScreen
                mapSettings: overlay.mapSettings
                mapPoint: modelData.edge ? GeometryUtils.point(modelData.edge.x, modelData.edge.y)
                                         : GeometryUtils.point(modelData.mapX, modelData.mapY)
            }
            readonly property real radiusPx: modelData.edge
                                              ? Math.sqrt(Math.pow(edgeScreen.screenPoint.x - centerScreen.screenPoint.x, 2) +
                                                          Math.pow(edgeScreen.screenPoint.y - centerScreen.screenPoint.y, 2))
                                              : 0

            /* Cercle de rayon D (masqué s'il est démesuré à l'écran) */
            Rectangle {
                visible: stationItem.radiusPx > 2 && stationItem.radiusPx < 30000
                x: centerScreen.screenPoint.x - stationItem.radiusPx
                y: centerScreen.screenPoint.y - stationItem.radiusPx
                width: stationItem.radiusPx * 2
                height: width
                radius: width / 2
                color: "transparent"
                border.color: overlay.stationColor
                border.width: 3
                opacity: 0.85
            }

            Rectangle {
                x: centerScreen.screenPoint.x - 14
                y: centerScreen.screenPoint.y - 14
                width: 28
                height: 28
                color: overlay.stationColor
                border.color: "white"
                border.width: 3
                Text {
                    anchors.centerIn: parent
                    text: modelData.label
                    color: "white"
                    font.pixelSize: 16
                    font.bold: true
                }
            }
        }
    }

    /* Flèche de sens de déplacement A -> B (aide gauche / droite) */
    Item {
        id: travelArrow
        anchors.fill: parent
        visible: overlay.od && overlay.od.stations.length === 2
        MapToScreen {
            id: aScreen
            mapSettings: overlay.mapSettings
            mapPoint: travelArrow.visible ? GeometryUtils.point(overlay.od.stations[0].mapX, overlay.od.stations[0].mapY)
                                          : GeometryUtils.point(0, 0)
        }
        MapToScreen {
            id: bScreen
            mapSettings: overlay.mapSettings
            mapPoint: travelArrow.visible ? GeometryUtils.point(overlay.od.stations[1].mapX, overlay.od.stations[1].mapY)
                                          : GeometryUtils.point(0, 0)
        }
        readonly property real dxs: bScreen.screenPoint.x - aScreen.screenPoint.x
        readonly property real dys: bScreen.screenPoint.y - aScreen.screenPoint.y
        readonly property real len: Math.sqrt(dxs * dxs + dys * dys)
        Rectangle {
            visible: travelArrow.len > 30
            x: aScreen.screenPoint.x
            y: aScreen.screenPoint.y - 2
            width: Math.max(0, travelArrow.len - 16)
            height: 4
            color: overlay.stationColor
            opacity: 0.8
            transformOrigin: Item.Left
            rotation: Math.atan2(travelArrow.dys, travelArrow.dxs) * 180 / Math.PI
        }
    }

    /* ---------------- Candidats P1 / P2 ---------------- */
    Repeater {
        model: overlay.od ? overlay.od.candidates : []
        delegate: Item {
            id: cand
            readonly property bool selected: modelData.selected
            readonly property color baseColor: modelData.side === "GAUCHE" ? overlay.p1Color
                                              : (modelData.side === "DROITE" ? overlay.p2Color : overlay.axisColor)
            MapToScreen {
                id: pScreen
                mapSettings: overlay.mapSettings
                mapPoint: GeometryUtils.point(modelData.mapX, modelData.mapY)
            }
            width: 72
            height: 72
            x: pScreen.screenPoint.x - width / 2
            y: pScreen.screenPoint.y - height / 2
            z: selected ? 2 : 1

            /* halo de sélection */
            Rectangle {
                anchors.centerIn: parent
                width: cand.selected ? 60 : 0
                height: width
                radius: width / 2
                color: "transparent"
                border.color: overlay.selectedColor
                border.width: 5
            }
            Rectangle {
                id: dot
                anchors.centerIn: parent
                width: cand.selected ? 30 : 24
                height: width
                radius: width / 2
                color: cand.selected ? overlay.selectedColor : cand.baseColor
                border.color: "white"
                border.width: 3
            }
            /* croix de visée au centre exact */
            Rectangle { anchors.centerIn: parent; width: 10; height: 2; color: "white" }
            Rectangle { anchors.centerIn: parent; width: 2; height: 10; color: "white" }

            Rectangle {
                /* étiquette à droite du point, ou à gauche près du bord de l'écran */
                x: pScreen.screenPoint.x + cand.width / 2 + width > overlay.width - 4 ? -width + 8 : cand.width - 8
                anchors.verticalCenter: parent.verticalCenter
                width: lbl.implicitWidth + 12
                height: lbl.implicitHeight + 6
                radius: 4
                color: cand.selected ? overlay.selectedColor : cand.baseColor
                border.color: "white"
                border.width: 1
                Text {
                    id: lbl
                    anchors.centerIn: parent
                    text: (cand.selected ? "✔ " : "") + modelData.label
                    color: "white"
                    font.pixelSize: 15
                    font.bold: true
                }
            }

            MouseArea {
                anchors.fill: parent
                onClicked: overlay.controller.selectCandidate(modelData.index)
            }
        }
    }
}
