/*
 * Mesurer support déporté — gros bouton lisible au soleil (hauteur 56 px)
 */
import QtQuick
import QtQuick.Controls

AbstractButton {
    id: btn

    property color fillColor: "#1565C0"
    property color textColor: "white"
    property int fontSize: 18
    property string subText: ""

    implicitHeight: subText === "" ? 56 : 66
    implicitWidth: Math.max(96, label.implicitWidth + 24)
    opacity: enabled ? 1.0 : 0.4

    background: Rectangle {
        radius: 8
        color: btn.down ? Qt.darker(btn.fillColor, 1.25) : btn.fillColor
        border.color: Qt.darker(btn.fillColor, 1.5)
        border.width: 2
    }

    contentItem: Item {
        implicitWidth: label.implicitWidth
        implicitHeight: col.implicitHeight
      Column {
        id: col
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width
        spacing: 2
        Text {
            id: label
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: btn.text
            color: btn.textColor
            font.pixelSize: btn.fontSize
            font.bold: true
            elide: Text.ElideRight
        }
        Text {
            visible: btn.subText !== ""
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: btn.subText
            color: btn.textColor
            font.pixelSize: 13
            elide: Text.ElideRight
        }
      }
    }
}
