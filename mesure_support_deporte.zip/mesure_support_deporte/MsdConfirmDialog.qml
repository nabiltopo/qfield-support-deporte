/*
 * Mesurer support déporté — boîte de confirmation (grands boutons, usage avec gants)
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Popup {
    id: dlg

    property string titleText: ""
    property string bodyText: ""
    property string acceptText: "OK"
    property var onAccept: null

    modal: true
    focus: true
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
    width: parent ? Math.min(parent.width - 32, 460) : 360
    x: parent ? (parent.width - width) / 2 : 0
    y: parent ? (parent.height - height) / 2 : 0
    padding: 20

    background: Rectangle {
        color: "white"
        radius: 10
        border.color: "#222222"
        border.width: 2
    }

    function ask(title, body, acceptLabel, callback) {
        titleText = title;
        bodyText = body;
        acceptText = acceptLabel || "OK";
        onAccept = callback;
        open();
    }

    contentItem: ColumnLayout {
        spacing: 16
        Label {
            Layout.fillWidth: true
            text: dlg.titleText
            font.pixelSize: 21
            font.bold: true
            color: "#111111"
            wrapMode: Text.WordWrap
        }
        Label {
            Layout.fillWidth: true
            text: dlg.bodyText
            font.pixelSize: 17
            color: "#222222"
            wrapMode: Text.WordWrap
        }
        RowLayout {
            Layout.fillWidth: true
            spacing: 12
            MsdBigButton {
                Layout.fillWidth: true
                text: "ANNULER"
                fillColor: "#ECEFF1"
                textColor: "#111111"
                onClicked: dlg.close()
            }
            MsdBigButton {
                Layout.fillWidth: true
                text: dlg.acceptText
                fillColor: "#C0392B"
                onClicked: {
                    var cb = dlg.onAccept;
                    dlg.close();
                    if (cb) {
                        cb();
                    }
                }
            }
        }
    }
}
