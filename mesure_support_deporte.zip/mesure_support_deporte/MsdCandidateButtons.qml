/*
 * Mesurer support déporté — choix du support « Sélectionner le support »
 * Un grand bouton par solution ; même choix possible en touchant la carte.
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ColumnLayout {
    id: cb

    property var controller: null
    property bool showHelp: true
    readonly property var res: controller ? controller.result : null

    visible: res !== null && res.ok
    spacing: 8

    Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: cb.res && cb.res.candidates.length === 2
              ? (cb.controller.selectedIndex < 0 ? "SÉLECTIONNER LE SUPPORT (carte ou boutons)" : "SÉLECTIONNER LE SUPPORT")
              : "SOLUTION UNIQUE (axe A-B)"
        font.pixelSize: 16
        font.bold: true
        color: "#111111"
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8
        Repeater {
            model: cb.res && cb.res.ok ? cb.res.candidates : []
            delegate: MsdBigButton {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.minimumWidth: 0
                readonly property bool selected: cb.controller.selectedIndex === index
                text: (selected ? "✔ " : "") + modelData.id +
                      (modelData.side === "GAUCHE" ? " ◀ GAUCHE" : (modelData.side === "DROITE" ? " DROITE ▶" : " (AXE)"))
                subText: "X " + modelData.x.toFixed(2) + "  Y " + modelData.y.toFixed(2)
                fontSize: 17
                fillColor: selected ? "#1B7F37" : (modelData.side === "GAUCHE" ? "#8E24AA" : (modelData.side === "DROITE" ? "#EF6C00" : "#00897B"))
                onClicked: cb.controller.selectCandidate(index)
            }
        }
    }

    Label {
        visible: cb.showHelp && cb.res !== null && cb.res.ok && cb.res.candidates.length === 2
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: "Gauche / droite par rapport au sens de déplacement A → B (flèche bleue sur la carte)."
        font.pixelSize: 13
        color: "#546E7A"
    }
}
