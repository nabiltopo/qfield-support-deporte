/*
 * Mesurer support déporté — actions sur le résultat
 *   [ VALIDER SUPPORT (journal) ]   [ COPIER X,Y ]
 * Phase 3 : la validation écrit le journal CSV de traçabilité / validation terrain.
 * Phase 4 : elle créera en plus l'entité dans la couche cible (non incluse).
 */
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

RowLayout {
    id: ra

    property var controller: null
    readonly property bool hasSelection: controller !== null && controller.selectedCandidate !== null
    readonly property string status: controller && controller.evaluation ? controller.evaluation.status : ""

    visible: controller !== null && controller.result !== null && controller.result.ok
    spacing: 8

    MsdBigButton {
        Layout.fillWidth: true
        Layout.preferredWidth: 3
        Layout.minimumWidth: 0
        text: "VALIDER SUPPORT"
        subText: ra.controller && ra.controller.config.journalEnabled ? "enregistrer dans le journal CSV" : "journal désactivé"
        fillColor: ra.status === "A_CONTROLER" ? "#D35400" : "#1B7F37"
        enabled: ra.hasSelection && ra.status !== "REPRENDRE"
        onClicked: ra.controller.requestValidate()
    }
    MsdBigButton {
        Layout.fillWidth: true
        Layout.preferredWidth: 1
        Layout.minimumWidth: 0
        text: "COPIER"
        subText: "X,Y"
        fillColor: "#455A64"
        enabled: ra.hasSelection
        onClicked: ra.controller.copySelectedToClipboard()
    }
}
