/*
 * Mesurer support déporté — Module 1 : gestion GNSS
 *
 * Lit la position courante fournie par QField (objet 'positionSource',
 * type QfPositioning / Positioning). Aucune connexion directe au récepteur :
 * l'Oscar RTK (ou tout autre récepteur) reste configuré dans QField.
 *
 * API QField utilisées (vérifiées sur QField 4.3.3) :
 *   positionSource.active, .projectedPosition (QgsPoint, CRS de la carte),
 *   .coordinateTransformer.destinationCrs, .positionInformation :
 *   latitudeValid, longitudeValid, latitude, longitude, elevation,
 *   elevationValid, hacc, haccValid, quality (GGA), qualityDescription,
 *   fixStatusDescription, satellitesUsed, utcDateTime.
 */
import QtQuick
import org.qfield
import org.qgis

import "js/quality.js" as Quality
import "js/journal.js" as Journal

QtObject {
    id: gnss

    property var positionSource: null

    readonly property bool available: positionSource !== null && positionSource !== undefined
    readonly property bool active: available && positionSource.active
    readonly property var info: available ? positionSource.positionInformation : null
    readonly property bool valid: active && info !== null && info !== undefined && info.latitudeValid && info.longitudeValid
    readonly property int quality: valid ? info.quality : -1
    readonly property real hacc: (valid && info.haccValid) ? info.hacc : NaN
    readonly property int satellites: valid ? info.satellitesUsed : 0

    readonly property string qualityLabel: {
        if (!available) {
            return "GNSS INDISPONIBLE";
        }
        if (!active) {
            return "GNSS INACTIF";
        }
        if (!valid) {
            return "PAS DE POSITION";
        }
        return Quality.ggaLabel(info.quality);
    }

    /* Couleur d'état : vert = RTK FIX, orange = FLOAT, rouge = autre */
    readonly property color statusColor: {
        if (!valid) {
            return "#C0392B";
        }
        if (quality === 4) {
            return "#1B7F37";
        }
        if (quality === 5) {
            return "#D35400";
        }
        return "#C0392B";
    }

    readonly property string accuracyText: isNaN(hacc) ? "—" : (hacc * 100).toFixed(1) + " cm"

    /*
     * Instantané de la position courante.
     * Retour : {ok, error, warning, point:{x,y,z} (CRS carte), crs, meta:{...}}
     */
    function snapshot() {
        if (!available) {
            return { ok: false, error: "Source de position QField introuvable." };
        }
        if (!positionSource.active) {
            return { ok: false, error: "Positionnement désactivé : activez le GNSS dans QField." };
        }
        var pi = positionSource.positionInformation;
        if (!pi || !pi.latitudeValid || !pi.longitudeValid) {
            return { ok: false, error: "Position GNSS non valide : attendez la réception." };
        }
        var p = positionSource.projectedPosition;
        if (!p || isNaN(p.x) || isNaN(p.y)) {
            return { ok: false, error: "Position projetée indisponible (CRS de la carte ?)." };
        }
        var crs = positionSource.coordinateTransformer ? positionSource.coordinateTransformer.destinationCrs : null;
        var z = NaN;
        if (p.z !== undefined && !isNaN(p.z)) {
            z = p.z;
        } else if (pi.elevationValid) {
            z = pi.elevation;
        }
        var ts = new Date();
        try {
            if (pi.utcDateTime && !isNaN(pi.utcDateTime.getTime())) {
                ts = pi.utcDateTime;
            }
        } catch (e) {
            /* date GNSS non convertible : heure du téléphone */
        }
        var warning = "";
        if (positionSource.currentness === false) {
            warning = "Position GNSS peut-être ancienne (pas de mise à jour récente).";
        }
        return {
            ok: true,
            error: "",
            warning: warning,
            point: { x: p.x, y: p.y, z: z },
            crs: crs,
            meta: {
                source: "GNSS",
                quality: pi.quality,
                qualityLabel: Quality.ggaLabel(pi.quality),
                qualityText: pi.qualityDescription,
                fixText: pi.fixStatusDescription,
                hacc: pi.haccValid ? pi.hacc : null,
                satellites: pi.satellitesUsed,
                lon: pi.longitude,
                lat: pi.latitude,
                timestamp: Journal.isoLocal(ts)
            }
        };
    }
}
