.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Module 3 : contrôle qualité
 * ============================================================================
 *
 *  Transforme un résultat du moteur (trilateration.js) en indicateur terrain :
 *     BON          (vert)
 *     A_CONTROLER  (orange)
 *     REPRENDRE    (rouge)
 *
 *  IMPORTANT : indicateur OPÉRATIONNEL de cohérence, pas une précision
 *  topographique garantie. « L'incertitude indicative » repose sur un modèle
 *  simplifié (distances indépendantes, écarts-types configurés) et n'a pas
 *  valeur de précision absolue.
 *
 *  Toutes les valeurs seuils proviennent de la configuration (config.js).
 * ============================================================================
 */

var STATUS = {
    BON: "BON",
    A_CONTROLER: "A_CONTROLER",
    REPRENDRE: "REPRENDRE"
};

var STATUS_INFO = {
    BON: { label: "BON", emoji: "🟢", color: "#1B7F37", rank: 0 },
    A_CONTROLER: { label: "À CONTRÔLER", emoji: "🟠", color: "#D35400", rank: 1 },
    REPRENDRE: { label: "REPRENDRE LA MESURE", emoji: "🔴", color: "#C0392B", rank: 2 }
};

var LEVEL = {
    INFO: "INFO",
    ALERTE: "ALERTE",   // dégrade au minimum à A_CONTROLER
    ERREUR: "ERREUR"    // dégrade à REPRENDRE
};

/* Codes qualité NMEA GGA (champ 6) tels que fournis par QField. */
var GGA = {
    INVALID: 0,
    AUTONOMOUS: 1,
    DGPS: 2,
    PPS: 3,
    RTK_FIXED: 4,
    RTK_FLOAT: 5,
    ESTIMATED: 6,
    MANUAL: 7,
    SIMULATION: 8
};

function _num(v) {
    return typeof v === "number" && isFinite(v);
}

function ggaLabel(q) {
    switch (q) {
    case 4: return "RTK FIX";
    case 5: return "RTK FLOAT";
    case 2: return "DGPS";
    case 1: return "AUTONOME";
    case 3: return "PPS";
    case 6: return "ESTIMÉ";
    case 7: return "MANUEL";
    case 8: return "SIMULATION";
    case 0: return "INVALIDE";
    default: return "INCONNU";
    }
}

/* Écart-type GNSS horizontal retenu pour une station (m). */
function stationGnssSigma(station, config) {
    if (station && _num(station.hacc) && station.hacc > 0) {
        return station.hacc;
    }
    return config.gnssSigmaDefault;
}

/* Écart-type combiné d'une mesure de distance (télémètre + position de la station). */
function rangeSigma(station, config) {
    var g = stationGnssSigma(station, config);
    var t = config.telemeterSigma;
    return Math.sqrt(t * t + g * g);
}

/*
 * Options passées au moteur : tolérance d'ajustement et poids des mesures.
 *   tolérance = clamp(k x sqrt(s1² + s2²), min, max)
 */
function engineOptions(stationA, stationB, config) {
    var s1 = rangeSigma(stationA, config);
    var s2 = rangeSigma(stationB, config);
    var tol = config.nearMissK * Math.sqrt(s1 * s1 + s2 * s2);
    if (tol < config.nearMissToleranceMin) {
        tol = config.nearMissToleranceMin;
    }
    if (tol > config.nearMissToleranceMax) {
        tol = config.nearMissToleranceMax;
    }
    return {
        nearMissTolerance: tol,
        weight1: s1 * s1,
        weight2: s2 * s2
    };
}

function _fmtM(v, digits) {
    return _num(v) ? v.toFixed(digits === undefined ? 2 : digits) + " m" : "—";
}

function _fmtCm(v) {
    return _num(v) ? (v * 100).toFixed(1) + " cm" : "—";
}

/* Contrôle GNSS d'une station ; ajoute des messages à `msgs`. */
function _checkStation(name, st, config, msgs) {
    if (!st) {
        return;
    }
    if (st.source !== "GNSS") {
        msgs.push({ level: LEVEL.INFO, code: "SIMULATION_" + name,
                    text: "Point " + name + " simulé (" + st.source + ") : contrôle GNSS non appliqué." });
        return;
    }
    var q = st.quality;
    if (!_num(q) || q === GGA.INVALID) {
        msgs.push({ level: LEVEL.ALERTE, code: "GNSS_UNKNOWN_" + name,
                    text: "Point " + name + " : statut GNSS inconnu ou invalide." });
    } else if (q === GGA.RTK_FIXED) {
        /* conforme */
    } else if (q === GGA.RTK_FLOAT) {
        msgs.push({ level: LEVEL.ALERTE, code: "GNSS_FLOAT_" + name,
                    text: "Point " + name + " : RTK FLOAT (non fixé)." });
    } else {
        msgs.push({ level: config.requireRtkFix ? LEVEL.ERREUR : LEVEL.ALERTE, code: "GNSS_NO_RTK_" + name,
                    text: "Point " + name + " : pas de solution RTK (" + ggaLabel(q) + ")." });
    }
    if (_num(st.hacc)) {
        if (st.hacc > config.haccBad) {
            msgs.push({ level: LEVEL.ERREUR, code: "HACC_BAD_" + name,
                        text: "Point " + name + " : précision " + _fmtCm(st.hacc) + " > " + _fmtCm(config.haccBad) + "." });
        } else if (st.hacc > config.haccWarn) {
            msgs.push({ level: LEVEL.ALERTE, code: "HACC_WARN_" + name,
                        text: "Point " + name + " : précision " + _fmtCm(st.hacc) + " > " + _fmtCm(config.haccWarn) + "." });
        }
    } else {
        msgs.push({ level: LEVEL.INFO, code: "HACC_NA_" + name,
                    text: "Point " + name + " : précision horizontale non fournie par le récepteur." });
    }
}

/*
 * evaluate({result, stationA, stationB, d1, d2, config})
 * Retour : {status, label, emoji, color, messages[], metrics{}}
 */
function evaluate(ctx) {
    var cfg = ctx.config;
    var r = ctx.result;
    var msgs = [];
    var metrics = {
        baseline: NaN,
        gap: NaN,
        tolerance: NaN,
        angleDeg: NaN,
        geometryFactor: Infinity,
        sigmaRange: NaN,
        sigmaIndicative: NaN,
        ratio: NaN,
        candidateSeparation: NaN,
        residual1: 0,
        residual2: 0,
        caseId: r ? r.caseId : ""
    };

    if (!r) {
        msgs.push({ level: LEVEL.ERREUR, code: "NO_RESULT", text: "Aucun calcul effectué." });
        return _finish(msgs, metrics);
    }

    metrics.baseline = r.baseline;
    metrics.gap = r.gap;
    metrics.tolerance = r.toleranceUsed;
    metrics.angleDeg = r.intersectionAngleDeg;
    metrics.geometryFactor = r.geometryFactor;
    metrics.candidateSeparation = r.candidateSeparation;
    metrics.residual1 = r.residual1;
    metrics.residual2 = r.residual2;

    var s1 = rangeSigma(ctx.stationA, cfg);
    var s2 = rangeSigma(ctx.stationB, cfg);
    metrics.sigmaRange = Math.sqrt((s1 * s1 + s2 * s2) / 2);
    if (_num(r.geometryFactor)) {
        metrics.sigmaIndicative = r.geometryFactor * metrics.sigmaRange;
    }
    var dmax = Math.max(_num(ctx.d1) ? ctx.d1 : 0, _num(ctx.d2) ? ctx.d2 : 0);
    if (_num(r.baseline) && dmax > 0) {
        metrics.ratio = r.baseline / dmax;
    }

    /* 1. Erreurs bloquantes du moteur */
    var i;
    switch (r.caseId) {
    case "INVALID_INPUT":
        for (i = 0; i < r.errors.length; i++) {
            msgs.push({ level: LEVEL.ERREUR, code: r.errors[i].code, text: r.errors[i].message });
        }
        return _finish(msgs, metrics);
    case "COINCIDENT_CENTERS":
        msgs.push({ level: LEVEL.ERREUR, code: "COINCIDENT",
                    text: "A et B identiques : avancez de " + cfg.baselineOptimalMin + " à " + cfg.baselineOptimalMax + " m avant de prendre B." });
        return _finish(msgs, metrics);
    case "NO_SOLUTION_SEPARATE":
        msgs.push({ level: LEVEL.ERREUR, code: "NO_SOLUTION_SEPARATE",
                    text: "Mesures incohérentes : D1 + D2 (" + _fmtM(ctx.d1 + ctx.d2) + ") < AB (" + _fmtM(r.baseline) +
                          "), écart " + _fmtM(r.gap) + " > tolérance " + _fmtM(r.toleranceUsed) +
                          ". Vérifiez D1/D2 et le pied de poteau visé, puis reprenez." });
        return _finish(msgs, metrics);
    case "NO_SOLUTION_CONTAINED":
        msgs.push({ level: LEVEL.ERREUR, code: "NO_SOLUTION_CONTAINED",
                    text: "Mesures incohérentes : |D1 − D2| (" + _fmtM(Math.abs(ctx.d1 - ctx.d2)) + ") > AB (" + _fmtM(r.baseline) +
                          "), écart " + _fmtM(r.gap) + " > tolérance " + _fmtM(r.toleranceUsed) +
                          ". Une distance est probablement erronée (inversion D1/D2 ?)." });
        return _finish(msgs, metrics);
    default:
        break;
    }

    /* 2. Cas 2 : ajustement / tangence */
    if (r.caseId === "ADJUSTED_SEPARATE" || r.caseId === "ADJUSTED_CONTAINED") {
        msgs.push({ level: LEVEL.ALERTE, code: r.caseId,
                    text: "Les cercles ne se coupent pas exactement (écart " + _fmtCm(r.gap) + ", tolérance " + _fmtCm(r.toleranceUsed) +
                          ") : solution ajustée sur l'axe A-B (corrections D1 " + _fmtCm(r.residual1) + ", D2 " + _fmtCm(r.residual2) + ")." });
    } else if (r.caseId === "TANGENT") {
        msgs.push({ level: LEVEL.ALERTE, code: "TANGENT",
                    text: "Cercles tangents : le support est dans l'axe A-B, position mal déterminée latéralement." });
    }

    /* 3. Distances */
    var dd = [["D1", ctx.d1], ["D2", ctx.d2]];
    for (i = 0; i < dd.length; i++) {
        var v = dd[i][1];
        if (!_num(v)) {
            continue;
        }
        if (v < cfg.distanceMin) {
            msgs.push({ level: LEVEL.ERREUR, code: dd[i][0] + "_TOO_SHORT",
                        text: dd[i][0] + " = " + _fmtM(v) + " < minimum " + _fmtM(cfg.distanceMin) + "." });
        } else if (v > cfg.distanceMaxHard) {
            msgs.push({ level: LEVEL.ERREUR, code: dd[i][0] + "_TOO_LONG",
                        text: dd[i][0] + " = " + _fmtM(v) + " > maximum " + _fmtM(cfg.distanceMaxHard) + " : valeur aberrante ?" });
        } else if (v > cfg.distanceMaxWarn) {
            msgs.push({ level: LEVEL.ALERTE, code: dd[i][0] + "_LONG",
                        text: dd[i][0] + " = " + _fmtM(v) + " : distance importante, vérifier la visée." });
        }
    }

    /* 4. Baseline et rapport baseline / distance */
    if (r.baseline < cfg.baselineMinHard) {
        msgs.push({ level: LEVEL.ERREUR, code: "BASELINE_TOO_SHORT",
                    text: "Baseline AB " + _fmtM(r.baseline) + " < " + _fmtM(cfg.baselineMinHard) + " : géométrie trop faible, reprenez B plus loin." });
    } else if (r.baseline < cfg.baselineMinRecommended) {
        msgs.push({ level: LEVEL.ALERTE, code: "BASELINE_SHORT",
                    text: "Géométrie faible : éloignez-vous davantage avant la deuxième mesure (AB = " + _fmtM(r.baseline) +
                          ", recommandé " + cfg.baselineOptimalMin + "–" + cfg.baselineOptimalMax + " m)." });
    }
    if (_num(metrics.ratio) && metrics.ratio < cfg.ratioMin) {
        msgs.push({ level: LEVEL.ALERTE, code: "RATIO_LOW",
                    text: "Baseline courte par rapport à la distance au support (rapport " + metrics.ratio.toFixed(2) +
                          " < " + cfg.ratioMin + ")." });
    }

    /* 5. Angle d'intersection (support proche de l'axe AB) */
    if (r.caseId === "TWO_POINTS" && _num(r.intersectionAngleDeg)) {
        var g = r.intersectionAngleDeg;
        if (g < cfg.angleMinDeg || g > 180 - cfg.angleMinDeg) {
            msgs.push({ level: LEVEL.ALERTE, code: "ANGLE_WEAK",
                        text: "Support presque dans l'axe A-B (angle d'intersection " + g.toFixed(0) +
                              "°) : prenez B plus en travers par rapport au support." });
        }
    }

    /* 6. GNSS */
    _checkStation("A", ctx.stationA, cfg, msgs);
    _checkStation("B", ctx.stationB, cfg, msgs);

    return _finish(msgs, metrics);
}

function _finish(msgs, metrics) {
    var status = STATUS.BON;
    for (var i = 0; i < msgs.length; i++) {
        if (msgs[i].level === LEVEL.ERREUR) {
            status = STATUS.REPRENDRE;
        } else if (msgs[i].level === LEVEL.ALERTE && status === STATUS.BON) {
            status = STATUS.A_CONTROLER;
        }
    }
    var info = STATUS_INFO[status];
    return {
        status: status,
        label: info.label,
        emoji: info.emoji,
        color: info.color,
        messages: msgs,
        metrics: metrics
    };
}

/* Classe de couleur de la baseline pour l'affichage en direct. */
function baselineClass(baseline, config) {
    if (!_num(baseline)) {
        return "NONE";
    }
    if (baseline < config.baselineMinHard) {
        return STATUS.REPRENDRE;
    }
    if (baseline < config.baselineMinRecommended) {
        return STATUS.A_CONTROLER;
    }
    return STATUS.BON;
}
