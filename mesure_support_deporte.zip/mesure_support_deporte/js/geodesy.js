.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Géodésie (facteur d'échelle local)
 * ============================================================================
 *
 *  Le télémètre mesure une distance « terrain ». Dans un CRS projeté, les
 *  distances de la grille diffèrent des distances terrain du facteur
 *  d'échelle local k de la projection :
 *        D_grille = k x D_terrain
 *  EPSG:26191 (Lambert conique conforme, k0 = 0,999625769) :
 *        k ≈ +560 ppm à Tanger (1,1 cm sur 20 m), ≈ -290 ppm à Rabat / Fès.
 *
 *  Le plugin estime k en transformant deux points de la grille distants de
 *  100 m vers WGS84 (API QField GeometryUtils.reprojectPoint), puis en
 *  mesurant leur distance géodésique (formule de Vincenty ci-dessous).
 *
 *  JavaScript pur, testé contre PROJ/pyproj (tests/run_tests.js).
 * ============================================================================
 */

var WGS84_A = 6378137.0;
var WGS84_F = 1 / 298.257223563;

/*
 * Distance géodésique (m) sur l'ellipsoïde WGS84 — Vincenty (1975), inverse.
 * Points en degrés {lon, lat}. Retour NaN si non-convergence (cas antipodal).
 */
function vincentyDistance(p1, p2) {
    var a = WGS84_A;
    var f = WGS84_F;
    var b = a * (1 - f);
    var rad = Math.PI / 180;
    var L = (p2.lon - p1.lon) * rad;
    var U1 = Math.atan((1 - f) * Math.tan(p1.lat * rad));
    var U2 = Math.atan((1 - f) * Math.tan(p2.lat * rad));
    var sinU1 = Math.sin(U1), cosU1 = Math.cos(U1);
    var sinU2 = Math.sin(U2), cosU2 = Math.cos(U2);
    var lambda = L;
    var lambdaP;
    var iter = 0;
    var sinSigma, cosSigma, sigma, sinAlpha, cos2Alpha, cos2SigmaM, C;
    do {
        var sinLambda = Math.sin(lambda), cosLambda = Math.cos(lambda);
        var t1 = cosU2 * sinLambda;
        var t2 = cosU1 * sinU2 - sinU1 * cosU2 * cosLambda;
        sinSigma = Math.sqrt(t1 * t1 + t2 * t2);
        if (sinSigma === 0) {
            return 0;   // points confondus
        }
        cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosLambda;
        sigma = Math.atan2(sinSigma, cosSigma);
        sinAlpha = cosU1 * cosU2 * sinLambda / sinSigma;
        cos2Alpha = 1 - sinAlpha * sinAlpha;
        cos2SigmaM = cos2Alpha !== 0 ? cosSigma - 2 * sinU1 * sinU2 / cos2Alpha : 0;
        C = f / 16 * cos2Alpha * (4 + f * (4 - 3 * cos2Alpha));
        lambdaP = lambda;
        lambda = L + (1 - C) * f * sinAlpha *
                 (sigma + C * sinSigma * (cos2SigmaM + C * cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM)));
        iter++;
    } while (Math.abs(lambda - lambdaP) > 1e-12 && iter < 200);
    if (iter >= 200) {
        return NaN;
    }
    var uSq = cos2Alpha * (a * a - b * b) / (b * b);
    var A = 1 + uSq / 16384 * (4096 + uSq * (-768 + uSq * (320 - 175 * uSq)));
    var B = uSq / 1024 * (256 + uSq * (-128 + uSq * (74 - 47 * uSq)));
    var deltaSigma = B * sinSigma * (cos2SigmaM + B / 4 * (cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM) -
                     B / 6 * cos2SigmaM * (-3 + 4 * sinSigma * sinSigma) * (-3 + 4 * cos2SigmaM * cos2SigmaM)));
    return b * A * (sigma - deltaSigma);
}

/*
 * Facteur d'échelle local k = distance grille / distance géodésique.
 *  gridDistance : distance (m) entre les deux points dans le CRS projeté
 *  geo1, geo2   : les mêmes points en WGS84 {lon, lat}
 * Retour NaN si les données sont incohérentes ; le plugin utilise alors k = 1.
 */
function localScaleFactor(gridDistance, geo1, geo2) {
    if (!(gridDistance > 0)) {
        return NaN;
    }
    var g = vincentyDistance(geo1, geo2);
    if (!(g > 0) || !isFinite(g)) {
        return NaN;
    }
    var k = gridDistance / g;
    /* garde-fou : toute projection utilisable localement reste à ±1 % */
    if (k < 0.99 || k > 1.01) {
        return NaN;
    }
    return k;
}

/* Réduction terrain -> grille d'une distance mesurée. */
function groundToGrid(distance, k) {
    if (!(k > 0) || !isFinite(k)) {
        return distance;
    }
    return distance * k;
}
