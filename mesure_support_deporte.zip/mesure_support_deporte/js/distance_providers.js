.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Abstraction DistanceProvider
 * ============================================================================
 *
 *  Contrat commun à toute source de distance (V1 manuelle, V2 Bluetooth) :
 *
 *    provider.id            : identifiant ("MANUAL", "BLUETOOTH", ...)
 *    provider.label         : libellé affiché
 *    provider.available     : true si utilisable dans cette version
 *    provider.capabilities  : {distance, azimuth, inclination} (booléens)
 *    provider.parse(input, config) -> Measurement
 *
 *  Measurement :
 *    { ok, value (m), azimuthDeg, inclinationDeg, source, raw, error, warning }
 *
 *  V1 : seul ManualDistanceProvider est implémenté (saisie clavier).
 *  V2 : BluetoothDistanceProvider devra produire le même objet Measurement ;
 *       l'interface et le moteur n'auront pas à changer.
 * ============================================================================
 */

var PROVIDER_MANUAL = "MANUAL";
var PROVIDER_BLUETOOTH = "BLUETOOTH";

function _measurement() {
    return {
        ok: false,
        value: NaN,
        azimuthDeg: NaN,
        inclinationDeg: NaN,
        source: PROVIDER_MANUAL,
        raw: "",
        error: "",
        warning: ""
    };
}

/*
 * Analyse d'une saisie manuelle : accepte "12.35", "12,35", " 12,35 m ", "12".
 * Refuse : vide, texte, négatif, zéro, notation exponentielle, séparateurs multiples.
 */
function parseManualDistance(input, config) {
    var m = _measurement();
    m.raw = (input === null || input === undefined) ? "" : String(input);
    var s = m.raw.trim().toLowerCase();
    if (s.length > 0 && s.charAt(s.length - 1) === "m") {
        s = s.substring(0, s.length - 1).trim();
    }
    s = s.replace(",", ".");
    if (s === "") {
        m.error = "Distance non saisie.";
        return m;
    }
    if (s.charAt(0) === "-") {
        m.error = "Distance négative interdite.";
        return m;
    }
    if (!/^\d+(\.\d+)?$/.test(s) && !/^\d*\.\d+$/.test(s)) {
        m.error = "Saisie non numérique : « " + m.raw + " ».";
        return m;
    }
    var v = parseFloat(s);
    if (!isFinite(v)) {
        m.error = "Saisie non numérique : « " + m.raw + " ».";
        return m;
    }
    if (v <= 0) {
        m.error = "Distance nulle interdite.";
        return m;
    }
    var cfg = config || {};
    var dMin = typeof cfg.distanceMin === "number" ? cfg.distanceMin : 0.5;
    var dWarn = typeof cfg.distanceMaxWarn === "number" ? cfg.distanceMaxWarn : 50;
    var dHard = typeof cfg.distanceMaxHard === "number" ? cfg.distanceMaxHard : 150;
    if (v < dMin) {
        m.error = "Distance " + v.toFixed(2) + " m inférieure au minimum (" + dMin + " m).";
        return m;
    }
    if (v > dHard) {
        m.error = "Distance " + v.toFixed(2) + " m supérieure au maximum (" + dHard + " m) : saisie aberrante ?";
        return m;
    }
    if (v > dWarn) {
        m.warning = "Distance importante (" + v.toFixed(2) + " m > " + dWarn + " m) : vérifier la visée.";
    }
    m.value = v;
    m.ok = true;
    return m;
}

var ManualDistanceProvider = {
    id: PROVIDER_MANUAL,
    label: "Saisie manuelle (télémètre simple)",
    available: true,
    capabilities: { distance: true, azimuth: false, inclination: false },
    parse: parseManualDistance
};

/* Emplacement réservé V2 : pas de dépendance Bluetooth en V1. */
var BluetoothDistanceProvider = {
    id: PROVIDER_BLUETOOTH,
    label: "Télémètre Bluetooth (Version 2)",
    available: false,
    capabilities: { distance: true, azimuth: true, inclination: true },
    parse: function (input, config) {
        var m = _measurement();
        m.source = PROVIDER_BLUETOOTH;
        m.error = "Télémètre Bluetooth non disponible en Version 1.";
        return m;
    }
};

function getProvider(id) {
    if (id === PROVIDER_BLUETOOTH) {
        return BluetoothDistanceProvider;
    }
    return ManualDistanceProvider;
}
