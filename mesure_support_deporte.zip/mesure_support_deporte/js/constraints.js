.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Contraintes géométriques (préparation V2)
 * ============================================================================
 *
 *  Fonctions pures pour la future option « Contraindre à un alignement » :
 *   - projection d'un point sur un segment / une polyligne ;
 *   - départage de P1 / P2 par la proximité d'un alignement connu.
 *
 *  NON BRANCHÉ sur l'interface en V1 : ces fonctions sont testées
 *  unitairement pour que l'intégration future se limite à l'interface.
 *
 *  Coordonnées planes métriques {x, y}. Déclarations `var`/`function` uniquement.
 * ============================================================================
 */

function _isPt(p) {
    return p !== null && p !== undefined && typeof p.x === "number" && typeof p.y === "number" &&
           isFinite(p.x) && isFinite(p.y);
}

/*
 * Projection orthogonale de P sur le segment [L1, L2].
 * Retour : {x, y, t, distance, clamped}
 *   t        : abscisse relative (0 = L1, 1 = L2) avant bornage
 *   clamped  : true si la projection tombe hors du segment (ramenée à l'extrémité)
 */
function projectPointOnSegment(P, L1, L2) {
    if (!_isPt(P) || !_isPt(L1) || !_isPt(L2)) {
        return null;
    }
    var vx = L2.x - L1.x;
    var vy = L2.y - L1.y;
    var len2 = vx * vx + vy * vy;
    if (len2 <= 0) {
        var d0 = Math.sqrt((P.x - L1.x) * (P.x - L1.x) + (P.y - L1.y) * (P.y - L1.y));
        return { x: L1.x, y: L1.y, t: 0, distance: d0, clamped: true };
    }
    var t = ((P.x - L1.x) * vx + (P.y - L1.y) * vy) / len2;
    var tc = t < 0 ? 0 : (t > 1 ? 1 : t);
    var x = L1.x + tc * vx;
    var y = L1.y + tc * vy;
    var dist = Math.sqrt((P.x - x) * (P.x - x) + (P.y - y) * (P.y - y));
    return { x: x, y: y, t: t, distance: dist, clamped: (t !== tc) };
}

/*
 * Projection de P sur une polyligne [{x,y}, ...] : segment le plus proche.
 * Retour : {x, y, distance, segmentIndex, t, clamped} ou null.
 */
function projectPointOnPolyline(P, vertices) {
    if (!_isPt(P) || !vertices || vertices.length < 2) {
        return null;
    }
    var best = null;
    for (var i = 0; i < vertices.length - 1; i++) {
        var pr = projectPointOnSegment(P, vertices[i], vertices[i + 1]);
        if (pr !== null && (best === null || pr.distance < best.distance)) {
            best = pr;
            best.segmentIndex = i;
        }
    }
    return best;
}

/*
 * Départage des candidats par un alignement (premier/dernier poteau ou polyligne).
 * Retour : {index, candidate, distances[], margin, decisive}
 *   decisive : true si l'écart de distance entre candidats dépasse minMargin (m).
 */
function chooseCandidateByAlignment(candidates, vertices, minMargin) {
    var margin0 = (typeof minMargin === "number" && isFinite(minMargin)) ? minMargin : 1.0;
    if (!candidates || candidates.length === 0) {
        return null;
    }
    var dists = [];
    var bestIdx = -1;
    for (var i = 0; i < candidates.length; i++) {
        var pr = projectPointOnPolyline(candidates[i], vertices);
        var d = pr ? pr.distance : Infinity;
        dists.push(d);
        if (bestIdx < 0 || d < dists[bestIdx]) {
            bestIdx = i;
        }
    }
    var margin = Infinity;
    for (var j = 0; j < dists.length; j++) {
        if (j !== bestIdx) {
            margin = Math.min(margin, dists[j] - dists[bestIdx]);
        }
    }
    return {
        index: bestIdx,
        candidate: candidates[bestIdx],
        distances: dists,
        margin: margin,
        decisive: margin >= margin0
    };
}
