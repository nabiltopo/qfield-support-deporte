.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Journal CSV et état de session (fonctions pures)
 * ============================================================================
 *
 *  - Colonnes de traçabilité (cahier des charges §12) + colonnes utiles à la
 *    validation terrain (§20) : X_ref / Y_ref sont laissées vides, à remplir
 *    avec le levé RTK direct au pied du support.
 *  - Encodage UTF-8 manuel vers un ArrayBuffer : FileUtils.writeFileContent()
 *    attend un QByteArray, l'ArrayBuffer est converti sans ambiguïté par Qt.
 *  - Sérialisation de session : conservation des mesures si QField change
 *    de fenêtre ou redémarre.
 * ============================================================================
 */

var METHODE_LEVE = "TRILATERATION_2_POINTS";
var MODE_CALCUL = "INTERSECTION_2_CERCLES";

var COLUMNS = [
    "id_mesure", "date_mesure", "operateur", "methode_leve", "mode_calcul", "source_positions", "crs_calcul",
    "XA", "YA", "ZA", "qualite_A", "precision_A", "date_A",
    "XB", "YB", "ZB", "qualite_B", "precision_B", "date_B",
    "D1", "D2", "mode_distance", "hauteur_visee", "D1_horizontale", "D2_horizontale", "baseline_AB",
    "cas_geometrique", "X_P1", "Y_P1", "X_P2", "Y_P2", "choix",
    "X_calc", "Y_calc", "residu", "correction_D1", "correction_D2",
    "angle_intersection", "incertitude_indicative", "Z_support", "mode_Z", "qualite_trilateration", "messages",
    "couche_cible", "entite_creee", "id_entite",
    "X_ref", "Y_ref"
];

function _n(v, digits) {
    if (typeof v !== "number" || !isFinite(v)) {
        return "";
    }
    return v.toFixed(digits);
}

function _escape(value, sep) {
    var s = (value === null || value === undefined) ? "" : String(value);
    if (s.indexOf(sep) >= 0 || s.indexOf("\"") >= 0 || s.indexOf("\n") >= 0 || s.indexOf("\r") >= 0) {
        s = "\"" + s.replace(/"/g, "\"\"") + "\"";
    }
    return s;
}

function headerLine(sep) {
    var out = [];
    for (var i = 0; i < COLUMNS.length; i++) {
        out.push(_escape(COLUMNS[i], sep));
    }
    return out.join(sep);
}

/*
 * record : {id, date, operator, crsAuthid, stationA, stationB, d1, d2,
 *           result, evaluation, selected}
 */
function buildRow(record) {
    var A = record.stationA || {};
    var B = record.stationB || {};
    var r = record.result || {};
    var ev = record.evaluation || { metrics: {}, messages: [] };
    var sel = record.selected || null;
    var alt = record.altimetry || {};
    var p1 = r.p1 || null;
    var p2 = r.p2 || null;
    var msgTexts = [];
    for (var i = 0; i < (ev.messages || []).length; i++) {
        msgTexts.push(ev.messages[i].level + ": " + ev.messages[i].text);
    }
    var residu = "";
    if (typeof r.gap === "number" && isFinite(r.gap)) {
        residu = r.gap;
    }
    var sources = (A.source || "") + "/" + (B.source || "");
    return {
        id_mesure: record.id || "",
        date_mesure: record.date || "",
        operateur: record.operator || "",
        methode_leve: METHODE_LEVE,
        mode_calcul: MODE_CALCUL + (r.adjusted ? "_AJUSTE" : ""),
        source_positions: sources,
        crs_calcul: record.crsAuthid || "",
        XA: _n(A.x, 3), YA: _n(A.y, 3), ZA: _n(A.z, 3),
        qualite_A: A.qualityLabel || "", precision_A: _n(A.hacc, 3), date_A: A.timestamp || "",
        XB: _n(B.x, 3), YB: _n(B.y, 3), ZB: _n(B.z, 3),
        qualite_B: B.qualityLabel || "", precision_B: _n(B.hacc, 3), date_B: B.timestamp || "",
        D1: _n(record.d1, 3), D2: _n(record.d2, 3),
        mode_distance: alt.slopeApplied === undefined ? "" : (alt.slopeApplied ? "INCLINEE" : "HORIZONTALE"),
        hauteur_visee: _n(record.sightHeight, 2),
        D1_horizontale: _n(alt.D1, 3), D2_horizontale: _n(alt.D2, 3),
        baseline_AB: _n(r.baseline, 3),
        cas_geometrique: r.caseId || "",
        X_P1: p1 ? _n(p1.x, 3) : "", Y_P1: p1 ? _n(p1.y, 3) : "",
        X_P2: (p2 && p2 !== p1) ? _n(p2.x, 3) : "", Y_P2: (p2 && p2 !== p1) ? _n(p2.y, 3) : "",
        choix: sel ? sel.id : "",
        X_calc: sel ? _n(sel.x, 3) : "", Y_calc: sel ? _n(sel.y, 3) : "",
        residu: _n(residu, 3),
        correction_D1: _n(r.residual1, 3), correction_D2: _n(r.residual2, 3),
        angle_intersection: _n(r.intersectionAngleDeg, 1),
        incertitude_indicative: _n(ev.metrics ? ev.metrics.sigmaIndicative : NaN, 3),
        Z_support: _n(alt.zP, 3),
        mode_Z: alt.zMode || "",
        qualite_trilateration: ev.status || "",
        messages: msgTexts.join(" | "),
        couche_cible: record.targetLayer || "",
        entite_creee: record.entityCreated || "",
        id_entite: (record.entityId === null || record.entityId === undefined) ? "" : String(record.entityId),
        X_ref: "", Y_ref: ""
    };
}

function rowLine(row, sep) {
    var out = [];
    for (var i = 0; i < COLUMNS.length; i++) {
        out.push(_escape(row[COLUMNS[i]], sep));
    }
    return out.join(sep);
}

function buildCsv(rows, sep) {
    var lines = [headerLine(sep)];
    for (var i = 0; i < rows.length; i++) {
        lines.push(rowLine(rows[i], sep));
    }
    return lines.join("\r\n") + "\r\n";
}

/* Encodage UTF-8 (avec BOM pour Excel) d'une chaîne JS vers un ArrayBuffer. */
function utf8Encode(str, withBom) {
    var bytes = [];
    if (withBom) {
        bytes.push(0xEF, 0xBB, 0xBF);
    }
    for (var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        if (c >= 0xD800 && c <= 0xDBFF && i + 1 < str.length) {
            var c2 = str.charCodeAt(i + 1);
            if (c2 >= 0xDC00 && c2 <= 0xDFFF) {
                c = 0x10000 + ((c - 0xD800) << 10) + (c2 - 0xDC00);
                i++;
            }
        }
        if (c < 0x80) {
            bytes.push(c);
        } else if (c < 0x800) {
            bytes.push(0xC0 | (c >> 6), 0x80 | (c & 0x3F));
        } else if (c < 0x10000) {
            bytes.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 0x3F), 0x80 | (c & 0x3F));
        } else {
            bytes.push(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 0x3F), 0x80 | ((c >> 6) & 0x3F), 0x80 | (c & 0x3F));
        }
    }
    var buf = new ArrayBuffer(bytes.length);
    var view = new Uint8Array(buf);
    for (var j = 0; j < bytes.length; j++) {
        view[j] = bytes[j];
    }
    return buf;
}

/*
 * Décodage UTF-8 d'un ArrayBuffer (FileUtils.readFileContent renvoie un QByteArray,
 * converti en ArrayBuffer par le moteur QML). BOM éventuel ignoré.
 */
function utf8Decode(buffer) {
    if (buffer === null || buffer === undefined) {
        return "";
    }
    if (typeof buffer === "string") {
        return buffer;
    }
    var b;
    try {
        b = new Uint8Array(buffer);
    } catch (e) {
        return String(buffer);
    }
    var out = "";
    var i = 0;
    if (b.length >= 3 && b[0] === 0xEF && b[1] === 0xBB && b[2] === 0xBF) {
        i = 3;
    }
    while (i < b.length) {
        var c = b[i++];
        var cp;
        if (c < 0x80) {
            cp = c;
        } else if (c >= 0xC0 && c < 0xE0 && i < b.length) {
            cp = ((c & 0x1F) << 6) | (b[i++] & 0x3F);
        } else if (c >= 0xE0 && c < 0xF0 && i + 1 < b.length) {
            cp = ((c & 0x0F) << 12) | ((b[i++] & 0x3F) << 6) | (b[i++] & 0x3F);
        } else if (c >= 0xF0 && i + 2 < b.length) {
            cp = ((c & 0x07) << 18) | ((b[i++] & 0x3F) << 12) | ((b[i++] & 0x3F) << 6) | (b[i++] & 0x3F);
        } else {
            cp = 0xFFFD;
        }
        if (cp > 0xFFFF) {
            cp -= 0x10000;
            out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
        } else {
            out += String.fromCharCode(cp);
        }
    }
    return out;
}

/*
 * Ajoute une ligne à un contenu CSV existant (texte). Crée l'en-tête si vide.
 */
function appendRow(existingText, row, sep) {
    var t = existingText || "";
    if (t.replace(/\s/g, "") === "") {
        t = headerLine(sep) + "\r\n";
    } else if (t.charAt(t.length - 1) !== "\n") {
        t += "\r\n";
    }
    return t + rowLine(row, sep) + "\r\n";
}

/* true si le contenu existant est vide ou commence par l'en-tête actuel (même jeu de colonnes). */
function headerMatches(existingText, sep) {
    var t = existingText || "";
    if (t.replace(/\s/g, "") === "") {
        return true;
    }
    var first = t.split(/\r?\n/)[0];
    return first === headerLine(sep);
}

/* Chemin de repli quand un ancien journal a d'autres colonnes : xxx.csv -> xxx_<n colonnes>col.csv */
function alternatePath(path) {
    var suffix = "_" + COLUMNS.length + "col";
    var dot = path.lastIndexOf(".");
    return dot > path.lastIndexOf("/") ? path.substring(0, dot) + suffix + path.substring(dot) : path + suffix;
}

/* Identifiant lisible : TRI_20260927_143512_3 */
function makeId(date, counter) {
    function p(v) { return (v < 10 ? "0" : "") + v; }
    return "TRI_" + date.getFullYear() + p(date.getMonth() + 1) + p(date.getDate()) + "_" +
           p(date.getHours()) + p(date.getMinutes()) + p(date.getSeconds()) + "_" + counter;
}

/* ISO 8601 local avec décalage horaire (ex. 2026-09-27T14:35:12+02:00). */
function isoLocal(date) {
    function p(v) { return (v < 10 ? "0" : "") + v; }
    var off = -date.getTimezoneOffset();
    var sign = off >= 0 ? "+" : "-";
    off = Math.abs(off);
    return date.getFullYear() + "-" + p(date.getMonth() + 1) + "-" + p(date.getDate()) + "T" +
           p(date.getHours()) + ":" + p(date.getMinutes()) + ":" + p(date.getSeconds()) +
           sign + p(Math.floor(off / 60)) + ":" + p(off % 60);
}

/* ---------------------------- Session ------------------------------------ */

var SESSION_VERSION = 1;

function serializeSession(s) {
    return JSON.stringify({
        v: SESSION_VERSION,
        stationA: s.stationA || null,
        stationB: s.stationB || null,
        d1Text: s.d1Text || "",
        d2Text: s.d2Text || "",
        crsAuthid: s.crsAuthid || "",
        projectPath: s.projectPath || "",
        simXA: s.simXA || "", simYA: s.simYA || "",
        simXB: s.simXB || "", simYB: s.simYB || ""
    });
}

function _validStation(st) {
    return st && typeof st.x === "number" && isFinite(st.x) && typeof st.y === "number" && isFinite(st.y);
}

function restoreSession(text) {
    var empty = { stationA: null, stationB: null, d1Text: "", d2Text: "", crsAuthid: "", projectPath: "",
                  simXA: "", simYA: "", simXB: "", simYB: "" };
    if (!text) {
        return empty;
    }
    try {
        var o = JSON.parse(String(text));
        if (!o || o.v !== SESSION_VERSION) {
            return empty;
        }
        return {
            stationA: _validStation(o.stationA) ? o.stationA : null,
            stationB: _validStation(o.stationB) ? o.stationB : null,
            d1Text: typeof o.d1Text === "string" ? o.d1Text : "",
            d2Text: typeof o.d2Text === "string" ? o.d2Text : "",
            crsAuthid: typeof o.crsAuthid === "string" ? o.crsAuthid : "",
            projectPath: typeof o.projectPath === "string" ? o.projectPath : "",
            simXA: String(o.simXA || ""), simYA: String(o.simYA || ""),
            simXB: String(o.simXB || ""), simYB: String(o.simYB || "")
        };
    } catch (e) {
        return empty;
    }
}
