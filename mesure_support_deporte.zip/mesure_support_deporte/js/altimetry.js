.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Altimétrie : Z du support et réduction de pente
 * ============================================================================
 *
 *  Données disponibles avec un télémètre simple (distance seule, sans angle) :
 *    ZA, ZB : altitude du SOL en A et B (GNSS RTK, hauteur d'antenne déduite par QField)
 *    S1, S2 : distances télémètre, mesurées le long de la visée (INCLINÉES)
 *    hv     : hauteur de visée du télémètre au-dessus du sol (paramètre, ~1,30 m en véhicule)
 *
 *  1) Z du support (pied du poteau) — interpolation le long de l'axe A-B :
 *       t  = a / d   (position du pied de la perpendiculaire, 0 = A, 1 = B)
 *       ZP = ZA + t (ZB - ZA)
 *     P1 et P2 ont le même t (symétriques par rapport à AB) : ZP ne dépend pas du côté.
 *     Hypothèse : terrain régulier entre la route et le pied du poteau
 *     (un fossé ou un talus n'est pas vu) -> Z ESTIMÉ, signalé comme tel.
 *
 *  2) Réduction à l'horizontale des distances inclinées :
 *       Δhi = (Zi + hv) - ZP        Di = √(Si² - Δhi²)
 *     ZP dépendant de Di (via a), on itère jusqu'à stabilité (< 0,5 mm).
 *     Sans altitude GNSS : terrain supposé plat, Δh = hv.
 *
 *  Effet typique (hv = 1,30 m) : S = 8 m -> D = 7,894 m (-10,6 cm).
 *  Ignorer la pente est donc une erreur SYSTÉMATIQUE de ~5 à 10 cm à courte distance.
 *
 *  JavaScript pur ; la fonction d'intersection est injectée (testable sous Node).
 * ============================================================================
 */

var MODE_INCLINEE = "INCLINEE";
var MODE_HORIZONTALE = "HORIZONTALE";

function _num(v) {
    return typeof v === "number" && isFinite(v);
}

/*
 * solve(A, B, S1, S2, options, intersect)
 *  options : {distanceType, sightHeight, scaleFactor, engineOptions, maxIterations}
 *  intersect(A, r1, B, r2, engineOptions) : Trilat.intersectCircles
 * Retour : {ok, error, result, D1, D2, dh1, dh2, zP, zMode, t, iterations,
 *           slopeApplied, reduction1, reduction2}
 */
function solve(A, B, S1, S2, options, intersect) {
    var o = options || {};
    var k = _num(o.scaleFactor) && o.scaleFactor > 0 ? o.scaleFactor : 1.0;
    var hv = _num(o.sightHeight) ? o.sightHeight : 0;
    var slope = o.distanceType !== MODE_HORIZONTALE;
    var maxIt = _num(o.maxIterations) ? o.maxIterations : 8;
    var hasZ = A && B && _num(A.z) && _num(B.z);
    var out = {
        ok: false, error: "", result: null,
        D1: S1, D2: S2, dh1: 0, dh2: 0,
        zP: null, zMode: hasZ ? "INTERPOLE_AB" : "INDISPONIBLE",
        t: NaN, iterations: 0, slopeApplied: slope,
        reduction1: 0, reduction2: 0
    };
    var zp = hasZ ? (A.z + B.z) / 2 : 0;
    for (var it = 0; it < maxIt; it++) {
        out.iterations = it + 1;
        if (slope) {
            var dh1 = hasZ ? (A.z + hv - zp) : hv;
            var dh2 = hasZ ? (B.z + hv - zp) : hv;
            if (!(_num(S1) && _num(S2)) || Math.abs(dh1) >= S1 || Math.abs(dh2) >= S2) {
                out.error = "Distance mesurée plus courte que la dénivelée de visée (Δh " +
                            Math.max(Math.abs(dh1), Math.abs(dh2)).toFixed(2) + " m) : vérifier D1/D2 et la hauteur de visée.";
                out.dh1 = dh1;
                out.dh2 = dh2;
                return out;
            }
            out.dh1 = dh1;
            out.dh2 = dh2;
            out.D1 = Math.sqrt(S1 * S1 - dh1 * dh1);
            out.D2 = Math.sqrt(S2 * S2 - dh2 * dh2);
        }
        var res = intersect(A, out.D1 * k, B, out.D2 * k, o.engineOptions);
        out.result = res;
        var t = (res && _num(res.a) && res.baseline > 0) ? res.a / res.baseline : 0.5;
        out.t = t;
        if (!hasZ) {
            break;                       // Δh constant : une seule passe suffit
        }
        var zNew = A.z + t * (B.z - A.z);
        var converged = Math.abs(zNew - zp) < 0.0005;
        zp = zNew;
        if (!slope || converged) {
            break;
        }
    }
    if (hasZ) {
        out.zP = zp;
    }
    out.reduction1 = S1 - out.D1;
    out.reduction2 = S2 - out.D2;
    out.ok = true;
    return out;
}

/*
 * Messages de contrôle altimétrique (niveaux du module qualité : INFO / ALERTE / ERREUR).
 * config : {maxSlopePercent}
 */
function messages(sol, A, B, config) {
    var msgs = [];
    if (!sol) {
        return msgs;
    }
    if (!sol.ok) {
        msgs.push({ level: "ERREUR", code: "SLOPE_INVALID", text: sol.error });
        return msgs;
    }
    if (sol.slopeApplied) {
        msgs.push({ level: "INFO", code: "SLOPE_REDUCED",
                    text: "Distances inclinées réduites à l'horizontale : D1 −" + (sol.reduction1 * 100).toFixed(1) +
                          " cm, D2 −" + (sol.reduction2 * 100).toFixed(1) + " cm (Δh " + sol.dh1.toFixed(2) + " / " + sol.dh2.toFixed(2) + " m)." });
    }
    if (sol.zMode === "INDISPONIBLE") {
        msgs.push({ level: "INFO", code: "Z_NA",
                    text: "Altitude GNSS indisponible : Z du support non calculé" + (sol.slopeApplied ? ", terrain supposé plat pour la réduction de pente." : ".") });
        return msgs;
    }
    msgs.push({ level: "INFO", code: "Z_EST",
                text: "Z support ≈ " + sol.zP.toFixed(2) + " m (interpolé sur A-B, t = " + sol.t.toFixed(2) + ")." });
    var cfg = config || {};
    var maxSlope = _num(cfg.maxSlopePercent) ? cfg.maxSlopePercent : 15;
    var ab = Math.sqrt(Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2));
    if (ab > 0) {
        var pct = Math.abs(B.z - A.z) / ab * 100;
        if (pct > maxSlope) {
            msgs.push({ level: "ALERTE", code: "STEEP",
                        text: "Forte pente entre A et B (" + pct.toFixed(0) + " %) : Z du support et réduction de pente moins fiables." });
        }
    }
    if (_num(sol.t) && (sol.t < -0.5 || sol.t > 1.5)) {
        msgs.push({ level: "ALERTE", code: "Z_EXTRAPOLATED",
                    text: "Support loin en dehors du segment A-B : Z extrapolé, à contrôler." });
    }
    return msgs;
}
