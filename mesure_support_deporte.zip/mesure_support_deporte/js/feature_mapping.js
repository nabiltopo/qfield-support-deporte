.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Module 5 : préparation de l'entité (fonctions pures)
 * ============================================================================
 *
 *  - Jetons de traçabilité ({D1}, {AB}, {qualite}, {resume}...) calculés à
 *    partir de la mesure validée.
 *  - Correspondance champ = modèle, configurable :
 *        "SU_MODE_LOCALISATION=Triangulé;SU_COMMENTAIRE={resume}"
 *    Un champ absent de la couche est ignoré (avertissement), jamais d'erreur.
 *  - Remplissage automatique des champs de traçabilité du cahier des charges
 *    (methode_leve, XA, YA, D1, D2, baseline_AB...) s'ils existent dans la couche.
 *  - Construction du WKT du point selon le type de géométrie de la couche.
 *
 *  JavaScript pur, testé dans tests/run_tests.js.
 * ============================================================================
 */

var METHODE_LEVE = "TRILATERATION_2_POINTS";

/* Correspondance adaptée au modèle SRM (couche EL_SUPPORT) */
var DEFAULT_MAPPING = "SU_MODE_LOCALISATION=Triangulé;SU_COMMENTAIRE={resume};SU_Z={Z_P};EL_COOR_Z={Z_P}";

/* Champs de traçabilité du cahier des charges -> jeton (remplis s'ils existent) */
var SPEC_FIELDS = {
    "methode_leve": "{methode}",
    "XA": "{XA}", "YA": "{YA}", "ZA": "{ZA}",
    "XB": "{XB}", "YB": "{YB}", "ZB": "{ZB}",
    "D1": "{D1}", "D2": "{D2}",
    "baseline_AB": "{AB}",
    "X_calc": "{X}", "Y_calc": "{Y}",
    "qualite_A": "{qualite_A}", "qualite_B": "{qualite_B}",
    "precision_A": "{precision_A}", "precision_B": "{precision_B}",
    "residu": "{residu}",
    "qualite_trilateration": "{qualite}",
    "date_mesure": "{date}",
    "operateur": "{operateur}",
    "mode_calcul": "{mode_calcul}"
};

function _num(v) {
    return typeof v === "number" && isFinite(v);
}

function _round(v, d) {
    if (!_num(v)) {
        return null;
    }
    var f = Math.pow(10, d);
    return Math.round(v * f) / f;
}

/*
 * Jetons disponibles pour les modèles.
 * record : {id, date, operator, crsAuthid, stationA, stationB, d1, d2,
 *           result, evaluation, selected}
 */
function buildTokens(record) {
    var A = record.stationA || {};
    var B = record.stationB || {};
    var r = record.result || {};
    var ev = record.evaluation || { metrics: {} };
    var sel = record.selected || {};
    var m = ev.metrics || {};
    var zMoy = (_num(A.z) && _num(B.z)) ? (A.z + B.z) / 2 : null;
    var alt = record.altimetry || {};
    var side = sel.side === "GAUCHE" ? "gauche" : (sel.side === "DROITE" ? "droite" : "axe");
    var t = {
        methode: METHODE_LEVE,
        mode_calcul: "INTERSECTION_2_CERCLES" + (r.adjusted ? "_AJUSTE" : ""),
        id_mesure: record.id || "",
        date: record.date || "",
        operateur: record.operator || "",
        crs: record.crsAuthid || "",
        XA: _round(A.x, 3), YA: _round(A.y, 3), ZA: _round(A.z, 3),
        XB: _round(B.x, 3), YB: _round(B.y, 3), ZB: _round(B.z, 3),
        D1: _round(record.d1, 3), D2: _round(record.d2, 3),
        AB: _round(r.baseline, 3),
        X: _round(sel.x, 3), Y: _round(sel.y, 3),
        Z_moy: _round(zMoy, 2),
        Z_P: _round(alt.zP, 2),
        mode_Z: alt.zMode || "",
        D1h: _round(alt.D1, 3), D2h: _round(alt.D2, 3),
        mode_distance: alt.slopeApplied ? "INCLINEE_REDUITE" : "HORIZONTALE",
        choix: sel.id || "",
        cote: side,
        qualite: ev.status || "",
        qualite_label: ev.label || "",
        qualite_A: A.qualityLabel || "",
        qualite_B: B.qualityLabel || "",
        precision_A: _round(A.hacc, 3),
        precision_B: _round(B.hacc, 3),
        residu: _round(r.gap, 3),
        angle: _round(r.intersectionAngleDeg, 1),
        incertitude: _round(m.sigmaIndicative, 3)
    };
    t.resume = buildResume(t);
    return t;
}

/* Texte court de traçabilité (champ commentaire). */
function buildResume(t) {
    function f(v, d) {
        return _num(v) ? v.toFixed(d) : "?";
    }
    var s = "Levé déporté trilatération 2 pts : D1 " + f(t.D1, 2) + " m, D2 " + f(t.D2, 2) +
            " m, AB " + f(t.AB, 2) + " m, " + t.choix + " " + t.cote + ", qualité " + t.qualite;
    if (_num(t.incertitude)) {
        s += " (±" + Math.round(t.incertitude * 100) + " cm indicatif)";
    }
    if (t.mode_distance === "INCLINEE_REDUITE") {
        s += ", distances inclinées réduites";
    }
    if (_num(t.Z_P)) {
        s += ", Z≈" + t.Z_P.toFixed(2) + " m interpolé";
    }
    if (t.qualite_A || t.qualite_B) {
        s += ", GNSS " + (t.qualite_A || "?") + "/" + (t.qualite_B || "?");
    }
    if (t.id_mesure) {
        s += ", réf. " + t.id_mesure;
    }
    return s;
}

/*
 * "CHAMP=modèle;CHAMP2=modèle2" -> {entries:[{field, template}], errors:[]}
 * Séparateurs acceptés : ";" ou retour à la ligne. Espaces autour du nom ignorés.
 */
function parseMapping(text) {
    var out = { entries: [], errors: [] };
    var s = (text === null || text === undefined) ? "" : String(text);
    var parts = s.split(/[;\n\r]+/);
    for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        if (p.replace(/\s/g, "") === "") {
            continue;
        }
        var eq = p.indexOf("=");
        if (eq <= 0) {
            out.errors.push("Correspondance ignorée (format CHAMP=valeur attendu) : « " + p.trim() + " »");
            continue;
        }
        var field = p.substring(0, eq).trim();
        var tpl = p.substring(eq + 1).trim();
        if (field === "") {
            out.errors.push("Nom de champ vide : « " + p.trim() + " »");
            continue;
        }
        out.entries.push({ field: field, template: tpl });
    }
    return out;
}

/*
 * Rendu d'un modèle.
 *  - "{D1}" seul -> valeur brute (nombre conservé, null si indisponible) ;
 *  - sinon substitution textuelle ; jeton inconnu laissé tel quel + signalé.
 * Retour : {value, unknown: [noms]}
 */
function render(template, tokens) {
    var unknown = [];
    var single = /^\{([A-Za-z_][A-Za-z0-9_]*)\}$/.exec(template);
    if (single) {
        if (tokens.hasOwnProperty(single[1])) {
            var v = tokens[single[1]];
            return { value: (v === undefined ? null : v), unknown: unknown };
        }
        unknown.push(single[1]);
        return { value: template, unknown: unknown };
    }
    var out = template.replace(/\{([A-Za-z_][A-Za-z0-9_]*)\}/g, function (all, name) {
        if (tokens.hasOwnProperty(name)) {
            var val = tokens[name];
            return (val === null || val === undefined) ? "" : String(val);
        }
        unknown.push(name);
        return all;
    });
    return { value: out, unknown: unknown };
}

function _findField(fieldNames, name) {
    var low = name.toLowerCase();
    for (var i = 0; i < fieldNames.length; i++) {
        if (String(fieldNames[i]).toLowerCase() === low) {
            return fieldNames[i];
        }
    }
    return null;
}

/*
 * Valeurs à pré-remplir dans l'entité.
 *  mappingText : correspondance configurée
 *  tokens      : buildTokens()
 *  fieldNames  : champs de la couche cible
 *  options     : {autoSpecFields: bool, maxTextLength: int}
 * Retour : {presets:[{field, value}], warnings:[]}
 * La correspondance explicite est prioritaire sur le remplissage automatique.
 */
function buildPresets(mappingText, tokens, fieldNames, options) {
    var opt = options || {};
    var maxLen = _num(opt.maxTextLength) && opt.maxTextLength > 0 ? opt.maxTextLength : 0;
    var res = { presets: [], warnings: [] };
    var used = {};
    var parsed = parseMapping(mappingText);
    var i;
    for (i = 0; i < parsed.errors.length; i++) {
        res.warnings.push(parsed.errors[i]);
    }

    function add(fieldName, template, explicit) {
        var real = _findField(fieldNames, fieldName);
        if (real === null) {
            if (explicit) {
                res.warnings.push("Champ « " + fieldName + " » absent de la couche : ignoré.");
            }
            return;
        }
        if (used[real.toLowerCase()]) {
            return;
        }
        var rr = render(template, tokens);
        if (rr.unknown.length > 0) {
            res.warnings.push("Jeton(s) inconnu(s) pour « " + real + " » : " + rr.unknown.join(", "));
        }
        var v = rr.value;
        if (v === null || v === undefined) {
            return;   // valeur indisponible : on laisse le champ à sa valeur par défaut
        }
        if (typeof v === "string" && maxLen > 0 && v.length > maxLen) {
            v = v.substring(0, maxLen - 1) + "…";
        }
        used[real.toLowerCase()] = true;
        res.presets.push({ field: real, value: v });
    }

    for (i = 0; i < parsed.entries.length; i++) {
        add(parsed.entries[i].field, parsed.entries[i].template, true);
    }
    if (opt.autoSpecFields) {
        for (var k in SPEC_FIELDS) {
            if (SPEC_FIELDS.hasOwnProperty(k)) {
                add(k, SPEC_FIELDS[k], false);
            }
        }
    }
    return res;
}

/*
 * WKT d'un point selon le type de géométrie de la couche.
 * flags : {multi, hasZ, hasM}
 */
function pointWkt(x, y, z, flags) {
    var f = flags || {};
    var zz = _num(z) ? z : 0;
    var coords = x + " " + y;
    var tag = "POINT";
    if (f.hasZ && f.hasM) {
        tag = "POINTZM";
        coords += " " + zz + " 0";
    } else if (f.hasZ) {
        tag = "POINTZ";
        coords += " " + zz;
    } else if (f.hasM) {
        tag = "POINTM";
        coords += " 0";
    }
    if (f.multi) {
        return "MULTI" + tag + "((" + coords + "))";
    }
    return tag + "(" + coords + ")";
}

/* Expression QGIS pour retrouver l'entité créée (contrôle enregistré / annulé). */
function lookupExpression(linkField, linkValue, x, y, tolerance) {
    if (linkField && linkValue !== null && linkValue !== undefined && String(linkValue) !== "") {
        return "\"" + String(linkField).replace(/"/g, "\"\"") + "\" = '" + String(linkValue).replace(/'/g, "''") + "'";
    }
    var tol = _num(tolerance) ? tolerance : 0.01;
    return "distance($geometry, make_point(" + x + ", " + y + ")) < " + tol;
}
