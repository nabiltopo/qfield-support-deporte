.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Module 2 : moteur mathématique de trilatération
 * ============================================================================
 *
 *  Intersection analytique de deux cercles :
 *     Cercle 1 : centre A, rayon D1
 *     Cercle 2 : centre B, rayon D2
 *
 *  JavaScript PUR : aucune dépendance à QField, Qt ou QGIS.
 *   - dans QField :  import "js/trilateration.js" as Trilat
 *   - dans Node.js : chargé par tests/run_tests.js (voir tests/qmljs_loader.js)
 *
 *  Conventions :
 *   - coordonnées planes d'un CRS PROJETÉ MÉTRIQUE (X = Est, Y = Nord) ;
 *   - distances en mètres ;
 *   - P1 est la solution située À GAUCHE du sens de déplacement A -> B,
 *     P2 la solution À DROITE (repère X Est / Y Nord).
 *
 *  Contrainte de compatibilité : déclarations de haut niveau en `var` et
 *  `function` uniquement (moteur QML V4 + chargeur Node des tests).
 * ============================================================================
 */

var ENGINE_VERSION = "1.0.0";

/* Identifiants des cas géométriques renvoyés par intersectCircles(). */
var CASE = {
    INVALID_INPUT: "INVALID_INPUT",               // données non numériques / distances <= 0
    COINCIDENT_CENTERS: "COINCIDENT_CENTERS",     // A et B confondus
    TWO_POINTS: "TWO_POINTS",                     // Cas 1 : deux intersections
    TANGENT: "TANGENT",                           // cercles tangents : une solution
    ADJUSTED_SEPARATE: "ADJUSTED_SEPARATE",       // Cas 2 : D1 + D2 légèrement < AB -> ajustement
    ADJUSTED_CONTAINED: "ADJUSTED_CONTAINED",     // Cas 2 : |D1 - D2| légèrement > AB -> ajustement
    NO_SOLUTION_SEPARATE: "NO_SOLUTION_SEPARATE", // Cas 3 : D1 + D2 << AB
    NO_SOLUTION_CONTAINED: "NO_SOLUTION_CONTAINED" // Cas 3 : |D1 - D2| >> AB
};

var SIDE = {
    LEFT: "GAUCHE",
    RIGHT: "DROITE",
    AXIS: "AXE"
};

/* Valeurs par défaut des options numériques du moteur. */
var DEFAULT_ENGINE_OPTIONS = {
    nearMissTolerance: 0.0,       // m : incohérence acceptée et ajustée (Cas 2). 0 = aucun ajustement
    weight1: 1.0,                 // variance relative de la mesure 1 (A, D1)
    weight2: 1.0,                 // variance relative de la mesure 2 (B, D2)
    minCenterSeparation: 1e-6,    // m : en dessous, A et B sont considérés confondus
    tangentTolerance: 1e-3,       // m : si h < 1 mm, les deux solutions sont fusionnées
    relativeEpsilon: 1e-12        // tolérance d'arrondi relative à l'échelle du problème
};

/* -------------------------------------------------------------------------- */
/*  Outils de base                                                            */
/* -------------------------------------------------------------------------- */

function isFiniteNumber(v) {
    return typeof v === "number" && isFinite(v);
}

function isValidPoint(p) {
    return p !== null && p !== undefined && isFiniteNumber(p.x) && isFiniteNumber(p.y);
}

function distance(p, q) {
    var dx = q.x - p.x;
    var dy = q.y - p.y;
    return Math.sqrt(dx * dx + dy * dy);
}

/* Produit vectoriel (B - A) x (P - A) : > 0 si P est à gauche de A -> B. */
function cross(A, B, P) {
    return (B.x - A.x) * (P.y - A.y) - (B.y - A.y) * (P.x - A.x);
}

function sideOfLine(A, B, P, tolerance) {
    var tol = isFiniteNumber(tolerance) ? tolerance : 1e-9;
    var d = distance(A, B);
    if (d <= 0) {
        return SIDE.AXIS;
    }
    var signedDist = cross(A, B, P) / d;
    if (signedDist > tol) {
        return SIDE.LEFT;
    }
    if (signedDist < -tol) {
        return SIDE.RIGHT;
    }
    return SIDE.AXIS;
}

function mergeOptions(options) {
    var o = {};
    var k;
    for (k in DEFAULT_ENGINE_OPTIONS) {
        if (DEFAULT_ENGINE_OPTIONS.hasOwnProperty(k)) {
            o[k] = DEFAULT_ENGINE_OPTIONS[k];
        }
    }
    if (options) {
        for (k in options) {
            if (options.hasOwnProperty(k) && isFiniteNumber(options[k])) {
                o[k] = options[k];
            }
        }
    }
    if (o.nearMissTolerance < 0) {
        o.nearMissTolerance = 0;
    }
    if (!(o.weight1 > 0)) {
        o.weight1 = 1.0;
    }
    if (!(o.weight2 > 0)) {
        o.weight2 = 1.0;
    }
    return o;
}

/* Écarts |PA| - D1 et |PB| - D2 d'un point P : contrôle a posteriori. */
function residualsForPoint(P, A, r1, B, r2) {
    var v1 = distance(P, A) - r1;
    var v2 = distance(P, B) - r2;
    return {
        v1: v1,
        v2: v2,
        rms: Math.sqrt((v1 * v1 + v2 * v2) / 2),
        max: Math.max(Math.abs(v1), Math.abs(v2))
    };
}

/*
 * Angle d'intersection gamma (en degrés) au point P entre les directions
 * P->A et P->B, calculé par la loi des cosinus à partir de r1, r2 et d.
 * gamma = 90° : géométrie idéale ; gamma -> 0° ou 180° : cercles tangents,
 * support dans l'axe A-B, position très mal déterminée perpendiculairement.
 */
function intersectionAngleDeg(r1, r2, d) {
    if (!(r1 > 0) || !(r2 > 0)) {
        return NaN;
    }
    var c = (r1 * r1 + r2 * r2 - d * d) / (2 * r1 * r2);
    if (c > 1) {
        c = 1;
    }
    if (c < -1) {
        c = -1;
    }
    return Math.acos(c) * 180 / Math.PI;
}

/*
 * Facteur d'affaiblissement géométrique (type HDOP) d'un relèvement par deux
 * distances : sigma_P = facteur x sigma_distance, avec facteur = sqrt(2) / sin(gamma).
 * Dérivation : H = [u1 ; u2] (vecteurs unitaires), cov = s^2 (H^T H)^-1,
 * valeurs propres de H^T H = 1 +/- cos(gamma)  =>  trace = 2 / sin^2(gamma).
 * Vaut 1.414 à 90°, 2.83 à 30°, +infini à 0° / 180°.
 */
function geometryFactor(angleDeg) {
    if (!isFiniteNumber(angleDeg)) {
        return Infinity;
    }
    var s = Math.sin(angleDeg * Math.PI / 180);
    if (Math.abs(s) < 1e-12) {
        return Infinity;
    }
    return Math.SQRT2 / Math.abs(s);
}

function makeEmptyResult(A, r1, B, r2) {
    return {
        engineVersion: ENGINE_VERSION,
        ok: false,
        caseId: CASE.INVALID_INPUT,
        errors: [],
        inputs: { A: A, r1: r1, B: B, r2: r2 },
        baseline: NaN,
        separationGap: NaN,     // d - (r1 + r2) : > 0 => cercles disjoints extérieurs
        containmentGap: NaN,    // |r1 - r2| - d : > 0 => un cercle contient l'autre
        gap: NaN,               // max(separationGap, containmentGap, 0) : incohérence (m)
        toleranceUsed: NaN,
        a: NaN,
        h: NaN,
        foot: null,             // pied de la perpendiculaire (X0, Y0) sur l'axe AB
        adjusted: false,
        adjustedR1: NaN,
        adjustedR2: NaN,
        residual1: 0,           // correction appliquée à D1 (m) dans le cas ajusté
        residual2: 0,           // correction appliquée à D2 (m) dans le cas ajusté
        candidates: [],
        p1: null,
        p2: null,
        intersectionAngleDeg: NaN,
        geometryFactor: Infinity,
        candidateSeparation: NaN
    };
}

function addError(res, code, message) {
    res.errors.push({ code: code, message: message });
}

/* -------------------------------------------------------------------------- */
/*  Intersection de deux cercles                                              */
/* -------------------------------------------------------------------------- */

/*
 * intersectCircles(A, r1, B, r2, options)
 *
 *  A, B     : {x, y} en mètres (CRS projeté)
 *  r1, r2   : D1, D2 en mètres
 *  options  : voir DEFAULT_ENGINE_OPTIONS
 *
 *  Algorithme (formules du cahier des charges) :
 *    d  = |AB|
 *    a  = (D1² - D2² + d²) / (2d)
 *    h  = sqrt(D1² - a²)                    [calculé comme sqrt((D1-a)(D1+a))]
 *    X0 = XA + a (XB-XA)/d ; Y0 = YA + a (YB-YA)/d
 *    P1 = (X0 - h (YB-YA)/d , Y0 + h (XB-XA)/d)   -> à gauche de A->B
 *    P2 = (X0 + h (YB-YA)/d , Y0 - h (XB-XA)/d)   -> à droite de A->B
 *
 *  Robustesse :
 *    - validation des entrées, distances > 0, A != B ;
 *    - la condition d'existence est testée AVANT la racine carrée, via
 *      l'incohérence gap = max(d - (D1+D2), |D1-D2| - d) ;
 *    - gap <= 0              -> 2 solutions (ou tangence si h < tangentTolerance) ;
 *    - 0 < gap <= tolérance  -> ajustement pondéré des rayons (moindres carrés
 *                               au premier ordre) : solution unique sur l'axe AB ;
 *    - gap > tolérance       -> pas de solution, reprendre les mesures.
 */
function intersectCircles(A, r1, B, r2, options) {
    var opt = mergeOptions(options);
    var res = makeEmptyResult(A, r1, B, r2);
    res.toleranceUsed = opt.nearMissTolerance;

    /* 1. Validation des entrées */
    if (!isValidPoint(A)) {
        addError(res, "A_INVALID", "Position A absente ou invalide.");
    }
    if (!isValidPoint(B)) {
        addError(res, "B_INVALID", "Position B absente ou invalide.");
    }
    if (!isFiniteNumber(r1)) {
        addError(res, "D1_INVALID", "Distance D1 absente ou non numérique.");
    } else if (r1 <= 0) {
        addError(res, "D1_NON_POSITIVE", "Distance D1 nulle ou négative (" + r1 + " m).");
    }
    if (!isFiniteNumber(r2)) {
        addError(res, "D2_INVALID", "Distance D2 absente ou non numérique.");
    } else if (r2 <= 0) {
        addError(res, "D2_NON_POSITIVE", "Distance D2 nulle ou négative (" + r2 + " m).");
    }
    if (res.errors.length > 0) {
        res.caseId = CASE.INVALID_INPUT;
        return res;
    }

    /* 2. Baseline AB (calcul en coordonnées relatives à A) */
    var dx = B.x - A.x;
    var dy = B.y - A.y;
    var d = Math.sqrt(dx * dx + dy * dy);
    res.baseline = d;

    if (d < opt.minCenterSeparation) {
        res.caseId = CASE.COINCIDENT_CENTERS;
        addError(res, "COINCIDENT_CENTERS",
                 "A et B sont confondus (baseline " + d.toFixed(4) + " m) : intersection indéterminée.");
        return res;
    }

    var ux = dx / d;          // vecteur unitaire A -> B
    var uy = dy / d;
    var nx = -uy;             // normale à gauche de A -> B
    var ny = ux;

    var scale = Math.max(d, r1, r2, 1.0);
    var eps = opt.relativeEpsilon * scale;

    /* 3. Test d'existence (avant toute racine carrée) */
    res.separationGap = d - (r1 + r2);
    res.containmentGap = Math.abs(r1 - r2) - d;
    var gap = Math.max(res.separationGap, res.containmentGap);
    res.gap = gap > 0 ? gap : 0;

    var isSeparate = res.separationGap >= res.containmentGap;

    if (gap > eps) {
        if (gap <= opt.nearMissTolerance) {
            /* Cas 2 : incohérence faible -> ajustement pondéré des rayons.
               L'écart est réparti proportionnellement aux variances w1, w2 ;
               les cercles ajustés sont tangents : la solution est unique. */
            var w1 = opt.weight1 / (opt.weight1 + opt.weight2);
            var w2 = opt.weight2 / (opt.weight1 + opt.weight2);
            var r1a, r2a;
            if (isSeparate) {
                r1a = r1 + gap * w1;
                r2a = r2 + gap * w2;
                res.caseId = CASE.ADJUSTED_SEPARATE;
            } else if (r1 > r2) {
                r1a = r1 - gap * w1;
                r2a = r2 + gap * w2;
                res.caseId = CASE.ADJUSTED_CONTAINED;
            } else {
                r1a = r1 + gap * w1;
                r2a = r2 - gap * w2;
                res.caseId = CASE.ADJUSTED_CONTAINED;
            }
            var aAdj = (r1a * r1a - r2a * r2a + d * d) / (2 * d);
            var P = { x: A.x + aAdj * ux, y: A.y + aAdj * uy };
            res.adjusted = true;
            res.adjustedR1 = r1a;
            res.adjustedR2 = r2a;
            res.residual1 = r1a - r1;
            res.residual2 = r2a - r2;
            res.a = aAdj;
            res.h = 0;
            res.foot = { x: P.x, y: P.y };
            res.candidates = [{ id: "P", x: P.x, y: P.y, side: SIDE.AXIS }];
            res.p1 = res.candidates[0];
            res.p2 = res.candidates[0];
            res.intersectionAngleDeg = intersectionAngleDeg(r1a, r2a, d);
            res.geometryFactor = geometryFactor(res.intersectionAngleDeg);
            res.candidateSeparation = 0;
            res.ok = true;
            return res;
        }

        /* Cas 3 : incohérence trop forte */
        res.caseId = isSeparate ? CASE.NO_SOLUTION_SEPARATE : CASE.NO_SOLUTION_CONTAINED;
        if (isSeparate) {
            addError(res, "NO_INTERSECTION_SEPARATE",
                     "D1 + D2 = " + (r1 + r2).toFixed(2) + " m < AB = " + d.toFixed(2) +
                     " m (écart " + gap.toFixed(2) + " m) : les cercles ne se coupent pas.");
        } else {
            addError(res, "NO_INTERSECTION_CONTAINED",
                     "|D1 - D2| = " + Math.abs(r1 - r2).toFixed(2) + " m > AB = " + d.toFixed(2) +
                     " m (écart " + gap.toFixed(2) + " m) : un cercle contient l'autre.");
        }
        return res;
    }

    /* 4. Cas 1 : intersection (gap <= eps) */
    var a = (r1 * r1 - r2 * r2 + d * d) / (2 * d);
    var h2 = (r1 - a) * (r1 + a);     // forme factorisée : moins d'annulation numérique
    if (h2 < 0) {
        h2 = 0;                        // bruit d'arrondi au voisinage de la tangence
    }
    var h = Math.sqrt(h2);
    var x0 = A.x + a * ux;
    var y0 = A.y + a * uy;

    res.a = a;
    res.h = h;
    res.foot = { x: x0, y: y0 };
    res.intersectionAngleDeg = intersectionAngleDeg(r1, r2, d);
    res.geometryFactor = geometryFactor(res.intersectionAngleDeg);

    if (h < opt.tangentTolerance) {
        res.caseId = CASE.TANGENT;
        res.candidates = [{ id: "P", x: x0, y: y0, side: SIDE.AXIS }];
        res.p1 = res.candidates[0];
        res.p2 = res.candidates[0];
        res.candidateSeparation = 2 * h;
        res.ok = true;
        return res;
    }

    var p1 = { id: "P1", x: x0 + h * nx, y: y0 + h * ny, side: SIDE.LEFT };
    var p2 = { id: "P2", x: x0 - h * nx, y: y0 - h * ny, side: SIDE.RIGHT };
    res.caseId = CASE.TWO_POINTS;
    res.candidates = [p1, p2];
    res.p1 = p1;
    res.p2 = p2;
    res.candidateSeparation = 2 * h;
    res.ok = true;
    return res;
}

/* -------------------------------------------------------------------------- */
/*  Préparation Version 2 : N distances, moindres carrés (Gauss-Newton)       */
/* -------------------------------------------------------------------------- */

/*
 * trilaterateLeastSquares(stations, initial, options)
 *   stations : [{x, y, r, sigma}]  (au moins 2 ; 3 et plus = mesure de contrôle)
 *   initial  : {x, y} point de départ (ex. solution choisie de intersectCircles)
 *   Retour   : {ok, x, y, iterations, residuals[], rms, sigma0, redundancy}
 * Non utilisé par l'interface V1 : prévu pour la "troisième mesure de contrôle".
 */
function trilaterateLeastSquares(stations, initial, options) {
    var maxIter = (options && isFiniteNumber(options.maxIterations)) ? options.maxIterations : 20;
    var tol = (options && isFiniteNumber(options.convergence)) ? options.convergence : 1e-6;
    var out = { ok: false, x: NaN, y: NaN, iterations: 0, residuals: [], rms: NaN, sigma0: NaN, redundancy: 0, error: "" };

    if (!stations || stations.length < 2 || !isValidPoint(initial)) {
        out.error = "Au moins deux stations et un point initial valide sont nécessaires.";
        return out;
    }
    var x = initial.x;
    var y = initial.y;
    var i, it;
    for (it = 0; it < maxIter; it++) {
        var n11 = 0, n12 = 0, n22 = 0, t1 = 0, t2 = 0;
        for (i = 0; i < stations.length; i++) {
            var s = stations[i];
            var ddx = x - s.x;
            var ddy = y - s.y;
            var rho = Math.sqrt(ddx * ddx + ddy * ddy);
            if (rho < 1e-9) {
                out.error = "Point initial confondu avec une station.";
                return out;
            }
            var w = 1 / Math.pow(isFiniteNumber(s.sigma) && s.sigma > 0 ? s.sigma : 1, 2);
            var jx = ddx / rho;
            var jy = ddy / rho;
            var l = s.r - rho;
            n11 += w * jx * jx;
            n12 += w * jx * jy;
            n22 += w * jy * jy;
            t1 += w * jx * l;
            t2 += w * jy * l;
        }
        var det = n11 * n22 - n12 * n12;
        if (Math.abs(det) < 1e-15) {
            out.error = "Système singulier : géométrie dégénérée (stations alignées avec le point).";
            return out;
        }
        var cx = (n22 * t1 - n12 * t2) / det;
        var cy = (n11 * t2 - n12 * t1) / det;
        x += cx;
        y += cy;
        out.iterations = it + 1;
        if (Math.sqrt(cx * cx + cy * cy) < tol) {
            break;
        }
    }
    var sumSq = 0;
    var sumWSq = 0;
    for (i = 0; i < stations.length; i++) {
        var st = stations[i];
        var v = Math.sqrt((x - st.x) * (x - st.x) + (y - st.y) * (y - st.y)) - st.r;
        out.residuals.push(v);
        sumSq += v * v;
        var sg = isFiniteNumber(st.sigma) && st.sigma > 0 ? st.sigma : 1;
        sumWSq += (v * v) / (sg * sg);
    }
    out.redundancy = stations.length - 2;
    out.rms = Math.sqrt(sumSq / stations.length);
    out.sigma0 = out.redundancy > 0 ? Math.sqrt(sumWSq / out.redundancy) : NaN;
    out.x = x;
    out.y = y;
    out.ok = true;
    return out;
}
