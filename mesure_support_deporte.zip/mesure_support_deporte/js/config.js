.pragma library
/*
 * ============================================================================
 *  Mesurer support déporté — Module 6 : configuration
 * ============================================================================
 *
 *  - DEFAULTS : valeurs par défaut (aucun seuil n'est codé ailleurs en dur) ;
 *  - SCHEMA   : type, bornes, libellé et groupe de chaque paramètre
 *               (sert à la validation ET à générer l'écran Paramètres) ;
 *  - merge()  : fusionne une configuration stockée avec les défauts,
 *               corrige les valeurs hors bornes sans jamais planter.
 *
 *  Stockage dans QField : settings.value("mesure_support_deporte/config")
 *  sous forme de chaîne JSON (voir main.qml).
 * ============================================================================
 */

var CONFIG_VERSION = 1;
var SETTINGS_KEY_CONFIG = "mesure_support_deporte/config";
var SETTINGS_KEY_SESSION = "mesure_support_deporte/session";
var SETTINGS_KEY_JOURNAL = "mesure_support_deporte/journal";

var DEFAULTS = {
    configVersion: 1,

    /* CRS de calcul */
    calcCrsMode: "auto",            // "auto" : CRS de la carte s'il est projeté métrique, sinon fallbackCrs
                                    // "fixed": toujours fallbackCrs
    fallbackCrs: "EPSG:26191",      // Merchich / Nord Maroc
    applyScaleFactor: true,         // D_grille = k x D_mesurée (facteur d'échelle local de la projection)

    /* Modèle d'incertitude (indicatif) */
    telemeterSigma: 0.10,           // m, écart-type estimé du télémètre + visée
    gnssSigmaDefault: 0.03,         // m, si la précision GNSS n'est pas fournie
    nearMissK: 3.0,                 // facteur k : tolérance d'ajustement = k x sigma combiné
    nearMissToleranceMin: 0.10,     // m
    nearMissToleranceMax: 1.00,     // m

    /* Distances D1 / D2 */
    distanceMin: 0.5,               // m, en dessous : REPRENDRE
    distanceMaxWarn: 50,            // m, au-dessus : À CONTRÔLER
    distanceMaxHard: 150,           // m, au-dessus : REPRENDRE

    /* Baseline AB */
    baselineMinHard: 2.0,           // m, en dessous : REPRENDRE
    baselineMinRecommended: 5.0,    // m, en dessous : À CONTRÔLER
    baselineOptimalMin: 10.0,       // m, indicatif (affichage)
    baselineOptimalMax: 20.0,       // m, indicatif (affichage)
    ratioMin: 0.25,                 // baseline / max(D1, D2) minimal recommandé

    /* Angle d'intersection */
    angleMinDeg: 25,                // gamma hors [25° ; 155°] : À CONTRÔLER

    /* GNSS */
    haccWarn: 0.05,                 // m, précision horizontale au-delà : À CONTRÔLER
    haccBad: 0.30,                  // m, au-delà : REPRENDRE
    requireRtkFix: true,            // FLOAT = À CONTRÔLER ; autonome/DGPS = REPRENDRE si true

    /* Interface */
    defaultSide: "AUCUN",           // présélection "GAUCHE" | "DROITE" | "AUCUN"
    autoZoom: true,                 // cadrer A, B, P1, P2 après calcul

    /* Mode simulation (développeur / PC) */
    simulationMode: false,
    simulationSource: "CENTRE",     // "CENTRE" = centre de la carte, "XY" = saisie X/Y (CRS de calcul)

    /* Traçabilité */
    operator: "",
    journalEnabled: true,
    journalRelativePath: "trilateration/journal_trilateration.csv",
    csvSeparator: ";"
};

/*
 * type : "number" | "bool" | "enum" | "string"
 * group: regroupement dans l'écran Paramètres
 */
var SCHEMA = [
    { key: "calcCrsMode", type: "enum", options: ["auto", "fixed"], group: "CRS", label: "Mode CRS de calcul (auto = CRS carte si métrique)" },
    { key: "fallbackCrs", type: "string", group: "CRS", label: "CRS métrique de repli (ex. EPSG:26191)" },
    { key: "applyScaleFactor", type: "bool", group: "CRS", label: "Appliquer le facteur d'échelle de la projection" },

    { key: "telemeterSigma", type: "number", min: 0.001, max: 5, group: "Incertitudes", label: "Écart-type télémètre + visée (m)" },
    { key: "gnssSigmaDefault", type: "number", min: 0.001, max: 5, group: "Incertitudes", label: "Écart-type GNSS par défaut (m)" },
    { key: "nearMissK", type: "number", min: 1, max: 10, group: "Incertitudes", label: "Facteur k de tolérance d'ajustement" },
    { key: "nearMissToleranceMin", type: "number", min: 0, max: 5, group: "Incertitudes", label: "Tolérance d'ajustement mini (m)" },
    { key: "nearMissToleranceMax", type: "number", min: 0, max: 10, group: "Incertitudes", label: "Tolérance d'ajustement maxi (m)" },

    { key: "distanceMin", type: "number", min: 0.01, max: 10, group: "Distances", label: "Distance minimale acceptée (m)" },
    { key: "distanceMaxWarn", type: "number", min: 1, max: 1000, group: "Distances", label: "Distance au-delà de laquelle contrôler (m)" },
    { key: "distanceMaxHard", type: "number", min: 1, max: 5000, group: "Distances", label: "Distance maximale acceptée (m)" },

    { key: "baselineMinHard", type: "number", min: 0.1, max: 100, group: "Baseline", label: "Baseline minimale absolue (m)" },
    { key: "baselineMinRecommended", type: "number", min: 0.1, max: 200, group: "Baseline", label: "Baseline minimale recommandée (m)" },
    { key: "baselineOptimalMin", type: "number", min: 0.1, max: 500, group: "Baseline", label: "Baseline optimale : début (m)" },
    { key: "baselineOptimalMax", type: "number", min: 0.1, max: 1000, group: "Baseline", label: "Baseline optimale : fin (m)" },
    { key: "ratioMin", type: "number", min: 0, max: 5, group: "Baseline", label: "Rapport baseline / distance minimal" },

    { key: "angleMinDeg", type: "number", min: 1, max: 60, group: "Géométrie", label: "Angle d'intersection minimal (°)" },

    { key: "haccWarn", type: "number", min: 0.001, max: 10, group: "GNSS", label: "Précision GNSS : seuil d'alerte (m)" },
    { key: "haccBad", type: "number", min: 0.001, max: 50, group: "GNSS", label: "Précision GNSS : seuil de rejet (m)" },
    { key: "requireRtkFix", type: "bool", group: "GNSS", label: "Exiger RTK FIX (sinon À CONTRÔLER / REPRENDRE)" },

    { key: "defaultSide", type: "enum", options: ["AUCUN", "GAUCHE", "DROITE"], group: "Interface", label: "Présélection du côté (sens A→B)" },
    { key: "autoZoom", type: "bool", group: "Interface", label: "Cadrer la carte après calcul" },

    { key: "simulationMode", type: "bool", group: "Simulation", label: "Mode simulation (sans GNSS)" },
    { key: "simulationSource", type: "enum", options: ["CENTRE", "XY"], group: "Simulation", label: "Source simulée : centre carte ou saisie X/Y" },

    { key: "operator", type: "string", group: "Traçabilité", label: "Opérateur" },
    { key: "journalEnabled", type: "bool", group: "Traçabilité", label: "Écrire le journal CSV" },
    { key: "journalRelativePath", type: "string", group: "Traçabilité", label: "Chemin du journal (relatif au projet)" },
    { key: "csvSeparator", type: "enum", options: [";", ","], group: "Traçabilité", label: "Séparateur CSV" }
];

function schemaFor(key) {
    for (var i = 0; i < SCHEMA.length; i++) {
        if (SCHEMA[i].key === key) {
            return SCHEMA[i];
        }
    }
    return null;
}

function defaults() {
    return JSON.parse(JSON.stringify(DEFAULTS));
}

function _toNumber(v) {
    if (typeof v === "number") {
        return v;
    }
    if (typeof v === "string") {
        var s = v.replace(",", ".").trim();
        if (s === "") {
            return NaN;
        }
        return Number(s);
    }
    return NaN;
}

function _toBool(v) {
    if (typeof v === "boolean") {
        return v;
    }
    if (typeof v === "string") {
        return v === "true" || v === "1";
    }
    if (typeof v === "number") {
        return v !== 0;
    }
    return null;
}

/*
 * Fusion + validation. Retour : {config, warnings[]}
 * Une valeur invalide est remplacée par la valeur par défaut (jamais d'exception).
 */
function merge(stored) {
    var cfg = defaults();
    var warnings = [];
    if (stored === null || stored === undefined || typeof stored !== "object") {
        return { config: cfg, warnings: warnings };
    }
    for (var i = 0; i < SCHEMA.length; i++) {
        var s = SCHEMA[i];
        if (!stored.hasOwnProperty(s.key)) {
            continue;
        }
        var raw = stored[s.key];
        if (s.type === "number") {
            var n = _toNumber(raw);
            if (!isFinite(n)) {
                warnings.push(s.key + " : valeur non numérique, défaut conservé.");
            } else if ((s.min !== undefined && n < s.min) || (s.max !== undefined && n > s.max)) {
                warnings.push(s.key + " : " + n + " hors bornes [" + s.min + " ; " + s.max + "], défaut conservé.");
            } else {
                cfg[s.key] = n;
            }
        } else if (s.type === "bool") {
            var b = _toBool(raw);
            if (b === null) {
                warnings.push(s.key + " : booléen attendu, défaut conservé.");
            } else {
                cfg[s.key] = b;
            }
        } else if (s.type === "enum") {
            if (s.options.indexOf(raw) >= 0) {
                cfg[s.key] = raw;
            } else {
                warnings.push(s.key + " : valeur '" + raw + "' non autorisée, défaut conservé.");
            }
        } else {
            cfg[s.key] = (raw === null || raw === undefined) ? "" : String(raw);
        }
    }
    /* Cohérences croisées */
    if (cfg.baselineMinRecommended < cfg.baselineMinHard) {
        warnings.push("baselineMinRecommended < baselineMinHard : aligné sur baselineMinHard.");
        cfg.baselineMinRecommended = cfg.baselineMinHard;
    }
    if (cfg.distanceMaxHard < cfg.distanceMaxWarn) {
        warnings.push("distanceMaxHard < distanceMaxWarn : aligné sur distanceMaxWarn.");
        cfg.distanceMaxHard = cfg.distanceMaxWarn;
    }
    if (cfg.haccBad < cfg.haccWarn) {
        warnings.push("haccBad < haccWarn : aligné sur haccWarn.");
        cfg.haccBad = cfg.haccWarn;
    }
    if (cfg.nearMissToleranceMax < cfg.nearMissToleranceMin) {
        warnings.push("nearMissToleranceMax < nearMissToleranceMin : aligné.");
        cfg.nearMissToleranceMax = cfg.nearMissToleranceMin;
    }
    if (cfg.baselineOptimalMax < cfg.baselineOptimalMin) {
        cfg.baselineOptimalMax = cfg.baselineOptimalMin;
    }
    if (String(cfg.fallbackCrs).trim() === "") {
        cfg.fallbackCrs = DEFAULTS.fallbackCrs;
    }
    return { config: cfg, warnings: warnings };
}

function fromJson(text) {
    if (text === null || text === undefined || text === "") {
        return merge(null);
    }
    try {
        return merge(JSON.parse(String(text)));
    } catch (e) {
        var r = merge(null);
        r.warnings.push("Configuration stockée illisible, valeurs par défaut utilisées.");
        return r;
    }
}

function toJson(cfg) {
    return JSON.stringify(cfg);
}
