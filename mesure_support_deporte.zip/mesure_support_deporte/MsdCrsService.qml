/*
 * Mesurer support déporté — Gestion des systèmes de coordonnées
 *
 * Règle : le calcul est TOUJOURS fait dans un CRS projeté métrique.
 *   mode "auto"  : CRS de la carte s'il est projeté en mètres,
 *                  sinon config.fallbackCrs (EPSG:26191 par défaut),
 *                  sinon UTM WGS84 déterminé automatiquement.
 *   mode "fixed" : config.fallbackCrs (sinon UTM).
 *
 * Les transformations utilisent GeometryUtils.reprojectPoint(), qui applique
 * le contexte de transformation du projet QGIS (paramètres de datum choisis
 * dans le projet, ex. Merchich -> WGS84).
 */
import QtQuick
import org.qfield
import org.qgis

import "js/geodesy.js" as Geodesy

QtObject {
    id: crsService

    property var mapSettings: null
    property var config: null

    function mapCrs() {
        return mapSettings ? mapSettings.destinationCrs : null;
    }

    function isValidCrs(crs) {
        return crs !== null && crs !== undefined && crs.authid !== undefined && crs.authid !== "";
    }

    function _isMeters(unit) {
        try {
            if (typeof Qgis !== "undefined" && Qgis.DistanceUnit !== undefined && Qgis.DistanceUnit.Meters !== undefined) {
                return unit === Qgis.DistanceUnit.Meters;
            }
        } catch (e) {
            /* enum non exposé : valeur numérique ci-dessous */
        }
        return unit === 0; /* Qgis::DistanceUnit::Meters */
    }

    function isMetricProjected(crs) {
        return isValidCrs(crs) && !crs.isGeographic && _isMeters(crs.mapUnits);
    }

    function fromAuthid(authid) {
        if (!authid) {
            return null;
        }
        var crs = CoordinateReferenceSystemUtils.fromDescription(authid);
        return isValidCrs(crs) ? crs : null;
    }

    /* Transformation {x,y} src -> dst ; null si échec. */
    function transform(x, y, srcCrs, dstCrs) {
        if (!isValidCrs(srcCrs) || !isValidCrs(dstCrs)) {
            return null;
        }
        if (srcCrs.authid === dstCrs.authid) {
            return { x: x, y: y };
        }
        var p = GeometryUtils.reprojectPoint(GeometryUtils.point(x, y), srcCrs, dstCrs);
        if (!p || isNaN(p.x) || isNaN(p.y)) {
            return null;
        }
        return { x: p.x, y: p.y };
    }

    function toWgs84(x, y, crs) {
        var p = transform(x, y, crs, CoordinateReferenceSystemUtils.wgs84Crs());
        return p ? { lon: p.x, lat: p.y } : null;
    }

    function _utmFor(lon, lat) {
        var zone = Math.floor((lon + 180) / 6) + 1;
        zone = Math.max(1, Math.min(60, zone));
        var code = (lat >= 0 ? 32600 : 32700) + zone;
        return fromAuthid("EPSG:" + code);
    }

    /*
     * Détermine le CRS de calcul.
     * hintLonLat : {lon, lat} optionnel (position GNSS) pour le choix UTM.
     * Retour : {ok, crs, authid, origin: "CARTE"|"CONFIG"|"UTM", error}
     */
    function resolveCalcCrs(hintLonLat) {
        var cfg = config || {};
        var m = mapCrs();
        if (cfg.calcCrsMode !== "fixed" && isMetricProjected(m)) {
            return { ok: true, crs: m, authid: m.authid, origin: "CARTE", error: "" };
        }
        var f = fromAuthid(cfg.fallbackCrs);
        if (f && isMetricProjected(f)) {
            return { ok: true, crs: f, authid: f.authid, origin: "CONFIG", error: "" };
        }
        var ll = hintLonLat;
        if ((!ll || isNaN(ll.lon)) && mapSettings && isValidCrs(m)) {
            var c = mapSettings.center;
            ll = toWgs84(c.x, c.y, m);
        }
        if (ll && !isNaN(ll.lon)) {
            var u = _utmFor(ll.lon, ll.lat);
            if (u) {
                return { ok: true, crs: u, authid: u.authid, origin: "UTM", error: "" };
            }
        }
        return { ok: false, crs: null, authid: "", origin: "", error: "Impossible de déterminer un CRS métrique de calcul." };
    }

    /* Facteur d'échelle local de la projection au point (x, y) du CRS de calcul. */
    function scaleFactorAt(x, y, calcCrs) {
        var g1 = toWgs84(x, y, calcCrs);
        var g2 = toWgs84(x + 100.0, y, calcCrs);
        if (!g1 || !g2) {
            return NaN;
        }
        return Geodesy.localScaleFactor(100.0, g1, g2);
    }
}
